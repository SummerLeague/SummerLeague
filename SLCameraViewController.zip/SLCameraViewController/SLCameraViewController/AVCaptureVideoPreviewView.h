//
//  AVCaptureVideoPreviewView.h
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/6/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AVCaptureSession;

@interface AVCaptureVideoPreviewView : UIView

@property (nonatomic, strong) AVCaptureSession *session;

@end
