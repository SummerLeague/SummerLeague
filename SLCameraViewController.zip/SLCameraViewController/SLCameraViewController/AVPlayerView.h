//
//  AVPlayerView.h
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/8/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AVPlayer;

@interface AVPlayerView : UIView

@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, copy) NSString *videoGravity;

@end
