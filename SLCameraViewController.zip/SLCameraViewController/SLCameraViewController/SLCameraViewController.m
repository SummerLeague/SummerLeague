//
//  SLCameraViewController.m
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/6/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "SLCameraViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "AVCaptureVideoPreviewView.h"
#import "SLVideoPlaybackViewController.h"

static void *RecordingContext = &RecordingContext;
static void *SessionRunningAndDeviceAuthorizedContext = &SessionRunningAndDeviceAuthorizedContext;

@interface SLCameraViewController () <AVCaptureFileOutputRecordingDelegate>

@property (nonatomic, weak) IBOutlet AVCaptureVideoPreviewView *previewView;
@property (nonatomic, weak) IBOutlet UIButton *recordButton;
@property (nonatomic, weak) IBOutlet UIProgressView *recordProgressView;

@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) dispatch_queue_t sessionQueue;
@property (nonatomic, strong) AVCaptureDeviceInput *videoDeviceInput;
@property (nonatomic, strong) AVCaptureMovieFileOutput *movieFileOutput;
@property (nonatomic, copy, readonly) NSString *outputFilePath;
@property (nonatomic, strong) CADisplayLink *displayLink;

@property (nonatomic, assign) BOOL deviceAuthorized;
@property (nonatomic, readonly, getter = isSessionRunningAndDeviceAuthorized) BOOL sessionRunningAndDeviceAuthorized;
@property (nonatomic, assign) UIBackgroundTaskIdentifier backgroundTaskID;
@property (nonatomic, strong) id runtimeErrorHandlingObserver;
@property (nonatomic, assign) BOOL lockAutorotation;

+ (AVCaptureDevice *)deviceWithMediaType:(NSString *)mediaType preferringPosition:(AVCaptureDevicePosition)position;
+ (void)setFlashMode:(AVCaptureFlashMode)flashMode forDevice:(AVCaptureDevice *)device;

- (IBAction)toggleMovieRecording:(id)sender;
- (IBAction)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer;

- (void)authorizeCameraPermissions;
- (BOOL)addVideoInput;
- (BOOL)addAudioInput;
- (void)addMovieOutput;
- (void)onDisplayLink;

@end

@implementation SLCameraViewController

- (void)viewDidLoad;
{
	[super viewDidLoad];
	
	self.recordButton.enabled = NO;
	self.recordProgressView.alpha = 0.f;
	
	self.session = [[AVCaptureSession alloc] init];
	self.previewView.session = self.session;
	
	[self authorizeCameraPermissions];
	
	self.sessionQueue = dispatch_queue_create( "SLCameraViewController Session", DISPATCH_QUEUE_SERIAL );
	dispatch_async( self.sessionQueue, ^
	{
		self.backgroundTaskID = UIBackgroundTaskInvalid;
		
		[self addVideoInput];
		[self addAudioInput];
		[self addMovieOutput];
	});
}

- (void)viewWillAppear:(BOOL)animated;
{
	dispatch_async( self.sessionQueue, ^
	{
		[self addObserver:self forKeyPath:@"sessionRunningAndDeviceAuthorized" options:( NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew ) context:SessionRunningAndDeviceAuthorizedContext];
		[self addObserver:self forKeyPath:@"movieFileOutput.recording" options:(NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew) context:RecordingContext];
		
		__weak SLCameraViewController *weakSelf = self;
		self.runtimeErrorHandlingObserver = [[NSNotificationCenter defaultCenter] addObserverForName:AVCaptureSessionRuntimeErrorNotification object:self.sessionQueue queue:nil usingBlock:^(NSNotification *note)
		{
			SLCameraViewController *strongSelf = weakSelf;
			dispatch_async( strongSelf.sessionQueue, ^
			{
				// Manually restarting the session since it must have been stopped due to an error.
				[strongSelf.session startRunning];
				[strongSelf.recordButton setTitle:NSLocalizedString(@"Record", @"Recording button record title") forState:UIControlStateNormal];
			});
		}];
		
		[self.session startRunning];
	});
}

- (void)viewWillDisappear:(BOOL)animated;
{
	dispatch_async( self.sessionQueue, ^
	{
		[self.session stopRunning];
		
		[[NSNotificationCenter defaultCenter] removeObserver:self.runtimeErrorHandlingObserver];
		
		[self removeObserver:self forKeyPath:@"sessionRunningAndDeviceAuthorized" context:SessionRunningAndDeviceAuthorizedContext];
		[self removeObserver:self forKeyPath:@"movieFileOutput.recording" context:RecordingContext];
	});
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;
{
	if( [segue.identifier isEqualToString:@"viewVideoSegue"] )
	{
		SLVideoPlaybackViewController *viewController = segue.destinationViewController;
		viewController.assetPath = self.outputFilePath;
	}
}

- (BOOL)prefersStatusBarHidden;
{
	return YES;
}

- (BOOL)shouldAutorotate;
{
	return !self.lockAutorotation;
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration;
{
	( ( AVCaptureVideoPreviewLayer *)self.previewView.layer ).connection.videoOrientation = (AVCaptureVideoOrientation)toInterfaceOrientation;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
{
	if( context == RecordingContext )
	{
		BOOL isRecording = [change[ NSKeyValueChangeNewKey ] boolValue];
		
		dispatch_async( dispatch_get_main_queue(), ^
		{
			[self.recordButton setTitle:( isRecording ? NSLocalizedString( @"Stop", @"Recording button stop title" ) : NSLocalizedString( @"Record", @"Recording button record title" ) ) forState:UIControlStateNormal];
			self.recordButton.enabled = YES;
			self.recordProgressView.alpha = isRecording ? 1.f : 0.f;
			self.recordProgressView.progress = 0.f;
		});
	}
	else if( context == SessionRunningAndDeviceAuthorizedContext )
	{
		BOOL isRunning = [change[ NSKeyValueChangeNewKey ] boolValue];
		dispatch_async( dispatch_get_main_queue(), ^
		{
			self.recordButton.enabled = isRunning;
		});
	}
	else
	{
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (BOOL)isSessionRunningAndDeviceAuthorized
{
	return self.session.isRunning && self.deviceAuthorized;
}

- (NSString *)outputFilePath;
{
	return [NSTemporaryDirectory() stringByAppendingPathComponent:[@"movie" stringByAppendingPathExtension:@"mov"]];
}

+ (NSSet *)keyPathsForValuesAffectingSessionRunningAndDeviceAuthorized
{
	return [NSSet setWithObjects:@"session.running", @"deviceAuthorized", nil];
}

+ (AVCaptureDevice *)deviceWithMediaType:(NSString *)mediaType preferringPosition:(AVCaptureDevicePosition)position;
{
	NSArray *devices = [AVCaptureDevice devicesWithMediaType:mediaType];
	AVCaptureDevice *captureDevice = devices.firstObject;
	
	for( AVCaptureDevice *device in devices )
	{
		if( device.position == position)
		{
			captureDevice = device;
			break;
		}
	}
	
	return captureDevice;
}

+ (void)setFlashMode:(AVCaptureFlashMode)flashMode forDevice:(AVCaptureDevice *)device;
{
	if( device.hasFlash && [device isFlashModeSupported:flashMode] )
	{
		NSError *error = nil;
		if( [device lockForConfiguration:&error] )
		{
			device.flashMode = flashMode;
			[device unlockForConfiguration];
		}
		else
		{
			NSLog( @"SLCameraViewController: error in setFlashMode:forDevice: %@", error );
		}
	}
}

- (IBAction)toggleMovieRecording:(id)sender;
{
	self.recordButton.enabled = NO;

	dispatch_async( self.sessionQueue, ^
	{
		if( !self.movieFileOutput.isRecording )
		{
			self.lockAutorotation = YES;
			
			BOOL isDir = NO;
			if( [[NSFileManager defaultManager] fileExistsAtPath:self.outputFilePath isDirectory:&isDir] && !isDir )
			{
				[[NSFileManager defaultManager] removeItemAtURL:[NSURL fileURLWithPath:self.outputFilePath] error:nil];
			}
				
			if( [UIDevice currentDevice].isMultitaskingSupported )
			{
				self.backgroundTaskID = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
				AVCaptureVideoOrientation orientation = ( (AVCaptureVideoPreviewLayer *)self.previewView.layer ).connection.videoOrientation;
				[self.movieFileOutput connectionWithMediaType:AVMediaTypeVideo].videoOrientation = orientation;
				[SLCameraViewController setFlashMode:AVCaptureFlashModeOff forDevice:self.videoDeviceInput.device];
				[self.movieFileOutput startRecordingToOutputFileURL:[NSURL fileURLWithPath:self.outputFilePath] recordingDelegate:self];
			
				self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(onDisplayLink)];
				[self.displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
			}
		}
		else
		{
			[self.movieFileOutput stopRecording];
		}
	});
}

- (IBAction)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer;
{
	CGPoint focusPoint = [( ( AVCaptureVideoPreviewLayer *)self.previewView.layer ) captureDevicePointOfInterestForPoint:[gestureRecognizer locationInView:[gestureRecognizer view]]];
	
	dispatch_async( self.sessionQueue, ^
	{
		AVCaptureDevice *device = self.videoDeviceInput.device;
		NSError *error = nil;
		
		if( [device lockForConfiguration:&error] )
		{
			if( device.isFocusPointOfInterestSupported && [device isFocusModeSupported:AVCaptureFocusModeAutoFocus] )
			{
				device.focusMode = AVCaptureFocusModeAutoFocus;
				device.focusPointOfInterest = focusPoint;
			}
			
			if( device.isExposurePointOfInterestSupported && [device isExposureModeSupported:AVCaptureExposureModeAutoExpose] )
			{
				device.exposureMode = AVCaptureExposureModeAutoExpose;
				device.exposurePointOfInterest = focusPoint;
			}
			
			[device unlockForConfiguration];
		}
		else
		{
			NSLog( @"SLCameraViewController: error in focusAndExposeTap: %@", error );
		}
	});
}

- (void)authorizeCameraPermissions;
{
	[AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted)
	{
		self.deviceAuthorized = granted;
		if( !self.deviceAuthorized )
		{
			dispatch_async( dispatch_get_main_queue(), ^
			{
				[[[UIAlertView alloc] initWithTitle:@"Could not use Camera"
													 message:@"This application does not have permission to use Camera, please change privacy settings."
													delegate:self
										cancelButtonTitle:@"OK"
										otherButtonTitles:nil] show];
			});
		}
	}];
}

- (BOOL)addVideoInput;
{
	BOOL success = NO;
	NSError *error = nil;
	AVCaptureDevice *videoDevice = [SLCameraViewController deviceWithMediaType:AVMediaTypeVideo preferringPosition:AVCaptureDevicePositionBack];
	self.videoDeviceInput = [AVCaptureDeviceInput deviceInputWithDevice:videoDevice error:&error];
	
	if( !error )
	{
		if( [self.session canAddInput:self.videoDeviceInput] )
		{
			[self.session addInput:self.videoDeviceInput];
			success = YES;
		}
	}
	
	return success;
}

- (BOOL)addAudioInput;
{
	BOOL success = NO;
	NSError *error = nil;
	AVCaptureDevice *audioDevice = [AVCaptureDevice devicesWithMediaType:AVMediaTypeAudio].firstObject;
	AVCaptureDeviceInput *audioDeviceInput = [AVCaptureDeviceInput deviceInputWithDevice:audioDevice error:&error];
	
	if( !error )
	{
		if( [self.session canAddInput:audioDeviceInput] )
		{
			[self.session addInput:audioDeviceInput];
			success = YES;
		}
	}
	
	return success;
}

- (void)addMovieOutput;
{
	const Float64 maxSeconds = 10.f;
	const int32_t preferredTimeScale = 30;
	
	self.movieFileOutput = [[AVCaptureMovieFileOutput alloc] init];
	self.movieFileOutput.maxRecordedDuration = CMTimeMakeWithSeconds( maxSeconds, preferredTimeScale );
	
	if( [self.session canAddOutput:self.movieFileOutput] )
	{
		[self.session addOutput:self.movieFileOutput];
		AVCaptureConnection *connection = [self.movieFileOutput connectionWithMediaType:AVMediaTypeVideo];
		if( connection.isVideoStabilizationSupported )
		{
			connection.enablesVideoStabilizationWhenAvailable = YES;
		}
	}
}

- (void)onDisplayLink;
{
	Float64 recordedDuration = CMTimeGetSeconds( self.movieFileOutput.recordedDuration );
	Float64 maxDuration = CMTimeGetSeconds( self.movieFileOutput.maxRecordedDuration );
	self.recordProgressView.progress = MAX( 0.f, MIN( ( recordedDuration / maxDuration ), 1.f ) );
}

#pragma mark AVCaptureFileOutputRecordingDelegate

- (void)captureOutput:(AVCaptureFileOutput *)captureOutput didFinishRecordingToOutputFileAtURL:(NSURL *)outputFileURL fromConnections:(NSArray *)connections error:(NSError *)error;
{
	self.lockAutorotation = NO;
	
	[self.displayLink invalidate];
	self.displayLink = nil;
	
	AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:outputFileURL options:nil];
	if( urlAsset )
	{
		[self performSegueWithIdentifier:@"viewVideoSegue" sender:self];
	}
	
	if( self.backgroundTaskID != UIBackgroundTaskInvalid )
	{
		[[UIApplication sharedApplication] endBackgroundTask:self.backgroundTaskID];
	}
}

@end
