//
//  SLVideoPlaybackViewController.h
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/8/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLVideoPlaybackViewController : UIViewController

@property (nonatomic, copy) NSString *assetPath;

@end
