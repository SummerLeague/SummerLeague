//
//  AVPlayerView.m
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/8/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "AVPlayerView.h"
#import <AVFoundation/AVFoundation.h>

@implementation AVPlayerView

+ (Class)layerClass;
{
	return [AVPlayerLayer class];
}

- (AVPlayer *)player;
{
	return ( (AVPlayerLayer *)self.layer ).player;
}

- (void)setPlayer:(AVPlayer *)player;
{
	( (AVPlayerLayer *)self.layer ).player = player;
}

- (NSString *)videoGravity;
{
	return ( (AVPlayerLayer *)self.layer ).videoGravity;
}

- (void)setVideoGravity:(NSString *)videoGravity;
{
	( (AVPlayerLayer *)self.layer ).videoGravity = videoGravity;
}

@end
