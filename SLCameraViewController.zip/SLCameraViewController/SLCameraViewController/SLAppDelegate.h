//
//  SLAppDelegate.h
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/6/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
