//
//  AVCaptureVideoPreviewView.m
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/6/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "AVCaptureVideoPreviewView.h"
#import <AVFoundation/AVFoundation.h>

@implementation AVCaptureVideoPreviewView

+ (Class)layerClass;
{
	return [AVCaptureVideoPreviewLayer class];
}

- (AVCaptureSession *)session
{
	return ( (AVCaptureVideoPreviewLayer *)self.layer ).session;
}

- (void)setSession:(AVCaptureSession *)session
{
	( (AVCaptureVideoPreviewLayer *)self.layer ).session = session;
}

@end
