//
//  SLVideoPlaybackViewController.m
//  SLCameraViewController
//
//  Created by Mark Stultz on 12/8/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "SLVideoPlaybackViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "AVPlayerView.h"

static void *SLVideoPlaybackViewControllerStatusObservationContext = &SLVideoPlaybackViewControllerStatusObservationContext;

@interface SLVideoPlaybackViewController ()

@property (nonatomic, weak) IBOutlet AVPlayerView *playerView;

@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerItem *playerItem;

- (IBAction)close:(id)sender;
- (IBAction)save:(id)sender;

- (void)playerItemDidPlayToEnd:(NSNotification *)notification;

@end

@implementation SLVideoPlaybackViewController

- (void)viewWillAppear:(BOOL)animated;
{
	[super viewWillAppear:animated];
	
	AVURLAsset *urlAsset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:self.assetPath] options:nil];
	if( urlAsset )
	{
		[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryAmbient error:nil];

		self.playerItem = [AVPlayerItem playerItemWithAsset:urlAsset];
		[self addObserver:self forKeyPath:@"playerItem.status" options:( NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew ) context:SLVideoPlaybackViewControllerStatusObservationContext];
		
		self.player = [AVPlayer playerWithPlayerItem:self.playerItem];
		
		self.player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerItemDidPlayToEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
		
		self.playerView.player = self.player;
		self.playerView.videoGravity = AVLayerVideoGravityResizeAspect;
	}
}

- (void)viewWillDisappear:(BOOL)animated;
{
	[self removeObserver:self forKeyPath:@"playerItem.status"];
	
	[super viewWillDisappear:animated];
}

- (BOOL)prefersStatusBarHidden;
{
	return YES;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;
{
	if( context == SLVideoPlaybackViewControllerStatusObservationContext )
	{
		AVPlayerStatus status = [[change objectForKey:NSKeyValueChangeNewKey] integerValue];
		switch( status )
		{
			case AVPlayerStatusUnknown:
			{
			}
				break;
				
			case AVPlayerStatusReadyToPlay:
			{
				[self.player play];
			}
				break;
				
			case AVPlayerStatusFailed:
			{
				NSLog( @"AVPlayerStatusFailed: %@", self.playerItem.error );
			}
				break;
		}
	}
}

- (IBAction)close:(id)sender;
{
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)save:(id)sender;
{
	[[[ALAssetsLibrary alloc] init] writeVideoAtPathToSavedPhotosAlbum:[NSURL fileURLWithPath:self.assetPath] completionBlock:^(NSURL *assetURL, NSError *error)
	{
		if( error )
		{
			NSLog( @"SLVideoPlaybackViewController: error in save: %@", error );
		}
	}];
}

- (void)playerItemDidPlayToEnd:(NSNotification *)notification;
{
	AVPlayerItem *playerItem = [notification object];
	[playerItem seekToTime:kCMTimeZero];
}

@end
