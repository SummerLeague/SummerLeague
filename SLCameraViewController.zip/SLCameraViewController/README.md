SLCameraViewController
======================

An application that uses AVFoundation to capture video.
