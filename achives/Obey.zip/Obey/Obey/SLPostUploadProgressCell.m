//
//  SLPostUploadProgressCell.m
//  Obey
//
//  Created by Bradley Griffith on 1/26/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import "SLPostUploadProgressCell.h"
#import "SLProgressObserver.h"

@interface SLPostUploadProgressCell () <SLProgressObserverDelegate>
@property SLProgressObserver *observer;
@end

@implementation SLPostUploadProgressCell

- (void)setProgress:(NSProgress *)progress {
	_progress = progress;
	self.observer = [[SLProgressObserver alloc] initWithProgress:_progress];
	_observer.delegate = self;
}

#pragma mark - ProgressObserver delegate methods

- (void)observerDidChange:(SLProgressObserver *)observer
{
	dispatch_async(dispatch_get_main_queue(), ^{
		// Update the progress bar with the latest completion %
		_uploadProgressView.progress = observer.progress.fractionCompleted;
		
		NSLog(@"progress changed completedUnitCount[%lld]", observer.progress.completedUnitCount);
	});
}

- (void)observerDidCancel:(SLProgressObserver *)observer
{
	NSLog(@"progress canceled");
}

- (void)observerDidComplete:(SLProgressObserver *)observer
{
	dispatch_async(dispatch_get_main_queue(), ^{
		_uploadProgressView.hidden = YES;
		_uploadedMessage.hidden = NO;
		NSLog(@"progress complete");
	});
}

@end
