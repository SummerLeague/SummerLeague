//
//  Barcode.h
//  Obey
//
//  Created by Mark Stultz on 12/30/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Barcode : NSManagedObject

@property (nonatomic, copy) NSString *rulingClassId;
@property (nonatomic, copy) NSString *barcode;
@property (nonatomic, copy) NSString *barcodeType;
@property (nonatomic, copy) NSNumber *hits;
@property (nonatomic, copy) NSSet *posts;

+ (instancetype)barcodeWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
+ (instancetype)barcodeWithCode:(NSString *)code type:(NSString *)type inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

+ (NSString *)entityName;

@end
