//
//  SLPostCollectionViewCell.h
//  Obey
//
//  Created by Mark Stultz on 1/26/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SLCaptionTextStorage.h"

@protocol SLPostCollectionViewCellDelegate;

@interface SLPostCollectionViewCell : UICollectionViewCell

@property (nonatomic, weak) IBOutlet UIImageView *postImageView;
@property (nonatomic, weak) IBOutlet UITextView *captionTextView;
@property (nonatomic, strong) SLCaptionTextStorage *captionTextStorage;
@property (nonatomic, weak) id<SLPostCollectionViewCellDelegate> delegate;

@end

@protocol SLPostCollectionViewCellDelegate <NSObject>

@optional
- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didTapOnUsername:(NSString *)username;
- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didBeginPressOnUsername:(NSString *)username;
- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didEndPressOnUsername:(NSString *)username;

@end
