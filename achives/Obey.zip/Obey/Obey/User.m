//
//  User.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "User.h"

@interface User ()

+ (instancetype)findUserWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

@end

@implementation User

@dynamic rulingClassId;
@dynamic nickname;
@dynamic posts;

+ (instancetype)userWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	User *user = [self findUserWithPredicate:[NSPredicate predicateWithFormat:@"rulingClassId = %@", rulingClassId] inManagedObjectContext:managedObjectContext];
	if( !user )
	{
		user = [NSEntityDescription insertNewObjectForEntityForName:self.entityName inManagedObjectContext:managedObjectContext];
		user.rulingClassId = rulingClassId;
	}
	
	return user;
}

+ (instancetype)findUserWithNickname:(NSString *)nickname inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	return [self findUserWithPredicate:[NSPredicate predicateWithFormat:@"nickname = %@", nickname] inManagedObjectContext:managedObjectContext];
}

+ (NSString *)entityName
{
	return @"User";
}

+ (instancetype)findUserWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:self.entityName];
	request.predicate = predicate;
	NSArray *objects = [managedObjectContext executeFetchRequest:request error:nil];
	return objects.lastObject;
}

@end
