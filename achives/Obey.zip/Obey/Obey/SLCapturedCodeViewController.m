//
//  SLCapturedCodeViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/15/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLCapturedCodeViewController.h"
#import "SLCapturedBarcodeView.h"
#import "Barcode.h"

@interface SLCapturedCodeViewController ()

@property (nonatomic, weak) IBOutlet SLCapturedBarcodeView *barcodeView;
@property (nonatomic, weak) IBOutlet UILabel *hitCountLabel;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *networkActivityIndicator;

@end

@implementation SLCapturedCodeViewController

- (void)viewDidLoad
{
	self.hits = @"";
	self.busy = NO;
}

- (void)setBarcode:(Barcode *)barcode
{
	self.barcodeView.barcode = barcode;
}

- (void)setHits:(NSString *)hits
{
	self.hitCountLabel.text = hits;
}

- (void)setBusy:(BOOL)busy
{
	self.hitCountLabel.hidden = busy;
	self.networkActivityIndicator.hidden = !busy;
	
	if( busy )
	{
		[self.networkActivityIndicator startAnimating];
	}
	else
	{
		[self.networkActivityIndicator stopAnimating];
	}
}

@end
