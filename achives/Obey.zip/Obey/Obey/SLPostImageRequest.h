//
//  SLPostImageRequest.h
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SLPostImageResponse.h"

@class Barcode;
@class SLUploadProgressTask;

@interface SLPostImageRequest : NSObject

+ (SLUploadProgressTask *)postImage:(UIImage *)image caption:(NSString *)caption barcode:(Barcode *)barcode managedObjectContext:(NSManagedObjectContext *)managedObjectContext completion:(void (^)(NSError *error, SLUploadProgressTask *task, SLPostImageResponse *response))completion;

@end
