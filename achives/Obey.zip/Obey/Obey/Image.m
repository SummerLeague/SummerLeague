//
//  Image.m
//  Obey
//
//  Created by Mark Stultz on 1/30/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "Image.h"

@interface Image ()

+ (instancetype)findImageWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

@end

@implementation Image

@dynamic cdnURL;
@dynamic filename;
@dynamic imageData;

+ (instancetype)imageWithCDNURL:(NSString *)cdnURL filename:(NSString *)filename inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
{
	Image *image = [self findImageWithPredicate:[NSPredicate predicateWithFormat:@"cdnURL = %@ && filename = %@", cdnURL, filename] inManagedObjectContext:managedObjectContext];
	if( !image )
	{
		image = [NSEntityDescription insertNewObjectForEntityForName:self.entityName inManagedObjectContext:managedObjectContext];
		image.cdnURL = cdnURL;
		image.filename = filename;
	}
	
	return image;
}

+ (NSString *)entityName
{
	return @"Image";
}

+ (instancetype)findImageWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:self.entityName];
	request.predicate = predicate;
	NSArray *objects = [managedObjectContext executeFetchRequest:request error:nil];
	return objects.lastObject;
}

@end
