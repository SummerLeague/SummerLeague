//
//  SLNavigationController.m
//  Obey
//
//  Created by Mark Stultz on 1/6/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLNavigationController.h"

@implementation SLNavigationController

- (BOOL)shouldAutorotate
{
	return [self.visibleViewController shouldAutorotate];
}

@end
