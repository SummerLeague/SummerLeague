//
//  SLCameraViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/24/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <CoreImage/CoreImage.h>
#import <ImageIO/ImageIO.h>
#import "SLCameraViewController.h"
#import "SLCameraController.h"
#import "SLCapturedPhotoViewController.h"
#import "SLTransitionAnimator.h"
#import "UIImage+Resize.h"
#import "Barcode.h"
#import "SLRulingClassCache.h"

@interface SLCameraViewController () <SLCameraControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, strong) SLCameraController *cameraController;
@property (nonatomic, strong) UIImage *croppedCapturedImage;
@property (nonatomic, strong) SLTransitionAnimator *transitionAnimator;

- (IBAction)back:(id)sender;
- (IBAction)capture:(id)sender;

- (void)setupPreviewLayer;

@end

@implementation SLCameraViewController

- (void)viewDidLoad;
{
	[super viewDidLoad];
	
	self.cameraController = [[SLCameraController alloc] initWithMetadataCapture:NO stillImageCapture:YES];
	self.cameraController.delegate = self;
	
	[self setupPreviewLayer];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self.navigationController setNavigationBarHidden:YES animated:animated];
	[self.cameraController startCamera];
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	
	self.barcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if( [segue.identifier isEqualToString:@"viewPhotoSegue"] )
	{
		UIViewController *sourceViewController = segue.sourceViewController;
		UINavigationController *navigationController = sourceViewController.navigationController;
		navigationController.delegate = self;
		
		SLCapturedPhotoViewController *destinationViewController = segue.destinationViewController;
		destinationViewController.barcode = self.barcode;
		destinationViewController.image = _croppedCapturedImage;
	}
}

- (IBAction)back:(id)sender
{
	[self.cameraController teardownCamera];
	//[self.navigationController setNavigationBarHidden:NO animated:NO];
	//[self.navigationController popViewControllerAnimated:YES];
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)capture:(id)sender
{
	[self.cameraController captureImage:^(UIImage *image, NSError *error) {
		if( image )
		{
			_croppedCapturedImage = [self cropImage:image to:_previewLayer.bounds];
			[self performSegueWithIdentifier:@"viewPhotoSegue" sender:self];
		}
	}];
}

- (UIImage *)cropImage:(UIImage *)image to:(CGRect)rect
{
	
	CGSize newSize = rect.size;
	UIImage *resizedImage = [image resizedImageWithContentMode:UIViewContentModeScaleAspectFill
																		 bounds:CGSizeMake(newSize.width, newSize.height)
													  interpolationQuality:kCGInterpolationHigh];
	
	CGRect cropRect = CGRectMake(round((resizedImage.size.width - newSize.width) / 2),
										  round((resizedImage.size.height - newSize.height) / 2),
										  newSize.width,
										  newSize.height);
	UIImage *croppedImage = [resizedImage croppedImage:cropRect];
	
	return croppedImage;
}

- (void)setupPreviewLayer
{
	float minSize = MIN( self.view.bounds.size.width, self.view.bounds.size.height );
	CGRect bounds = CGRectMake( 0.f, 0.f, minSize, minSize );
	self.previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.cameraController.session];
	self.previewLayer.bounds = bounds;
	self.previewLayer.position = CGPointMake( CGRectGetMidX( self.view.bounds ), CGRectGetMidY( self.view.bounds ) );
	self.previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
	[self.view.layer addSublayer:self.previewLayer];
}

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                  animationControllerForOperation:(UINavigationControllerOperation)operation
                                               fromViewController:(UIViewController *)fromVC
                                                 toViewController:(UIViewController *)toVC
{
	if( !self.transitionAnimator )
	{
		self.transitionAnimator = [SLTransitionAnimator new];
	}
	
	self.navigationController.delegate = nil;
	
	return self.transitionAnimator;
}

@end
