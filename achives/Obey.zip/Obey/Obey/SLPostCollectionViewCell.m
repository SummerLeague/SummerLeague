//
//  SLPostCollectionViewCell.m
//  Obey
//
//  Created by Mark Stultz on 1/26/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostCollectionViewCell.h"

@interface SLPostCollectionViewCell ()

@property (nonatomic, strong) NSArray *usernames;
@property (nonatomic, strong) UITapGestureRecognizer *tapGestureRecognizer;
@property (nonatomic, strong) UILongPressGestureRecognizer *longPressGestureRecognizer;

- (void)sharedInit;

- (void)tap:(UIGestureRecognizer *)gestureRecognizer;
- (void)longPress:(UIGestureRecognizer *)gestureRecognizer;

- (CGPoint)locationInTextView:(UIGestureRecognizer *)gestureRecognizer;

@end

@implementation SLPostCollectionViewCell

- (id)init
{
	self = [super init];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (void)sharedInit
{
	self.captionTextStorage = [[SLCaptionTextStorage alloc] init];
}

- (void)awakeFromNib
{
	[super awakeFromNib];
	
	self.tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
	[self.tapGestureRecognizer setNumberOfTapsRequired:1];
	[self.captionTextView addGestureRecognizer:self.tapGestureRecognizer];
	
	self.longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
	self.longPressGestureRecognizer.minimumPressDuration = 0.25;
	[self.captionTextView addGestureRecognizer:self.longPressGestureRecognizer];
}

- (void)dealloc
{
	[self.captionTextView removeGestureRecognizer:self.tapGestureRecognizer];
	[self.captionTextView removeGestureRecognizer:self.longPressGestureRecognizer];
}

- (void)tap:(UIGestureRecognizer *)gestureRecognizer
{
	CGPoint location = [self locationInTextView:gestureRecognizer];
	NSUInteger characterIndex = [self.captionTextView.layoutManager characterIndexForPoint:location inTextContainer:self.captionTextView.textContainer fractionOfDistanceBetweenInsertionPoints:NULL];
	if( characterIndex < self.captionTextView.textStorage.length )
	{
		NSRange range;
		NSDictionary *attributes = [self.captionTextStorage attributesAtIndex:characterIndex effectiveRange:&range];
		if( [self.delegate respondsToSelector:@selector(postCollectionViewCell:didTapOnUsername:)] )
		{
			NSString *username = attributes[ @"SLUsernameAttributeName" ];
			[self.delegate postCollectionViewCell:self didTapOnUsername:username];
		}
	}
}

- (void)longPress:(UIGestureRecognizer *)gestureRecognizer
{
	CGPoint location = [self locationInTextView:gestureRecognizer];
	NSUInteger characterIndex = [self.captionTextView.layoutManager characterIndexForPoint:location inTextContainer:self.captionTextView.textContainer fractionOfDistanceBetweenInsertionPoints:NULL];
	if( characterIndex < self.captionTextView.textStorage.length )
	{
		if( gestureRecognizer.state == UIGestureRecognizerStateBegan )
		{
			NSRange range;
			NSDictionary *attributes = [self.captionTextStorage attributesAtIndex:characterIndex effectiveRange:&range];
			if( [self.delegate respondsToSelector:@selector(postCollectionViewCell:didTapOnUsername:)] )
			{
				NSString *username = attributes[ @"SLUsernameAttributeName" ];
				NSLog( @"press on %@", username );
			}
			
			self.captionTextStorage.activeUsername = [self.captionTextStorage usernameAtCharacterIndex:characterIndex];
		}
		else if( gestureRecognizer.state == UIGestureRecognizerStateEnded )
		{
			self.captionTextStorage.activeUsername = nil;
		}
	}
}

- (CGPoint)locationInTextView:(UIGestureRecognizer *)gestureRecognizer
{
	CGPoint location = [gestureRecognizer locationInView:self.captionTextView];
	location.x -= self.captionTextView.textContainerInset.left;
	location.y -= self.captionTextView.textContainerInset.top;
	return location;
}

@end
