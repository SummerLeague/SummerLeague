//
//  Post.h
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Barcode;
@class User;

@interface Post : NSManagedObject

@property (nonatomic, copy) NSString *rulingClassId;
@property (nonatomic, strong) User *creator;
@property (nonatomic, strong) Barcode *barcode;
@property (nonatomic, copy) NSString *text;
@property (nonatomic, copy) NSString *cdnUri;
@property (nonatomic, copy) NSString *file;

+ (instancetype)postWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

+ (NSString *)entityName;

+ (NSFetchedResultsController *)postsFetchedResultsControllerForBarcode:(Barcode *)barcode inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
+ (NSFetchedResultsController *)postsFetchedResultsControllerForUser:(User *)user inManagedObjetContext:(NSManagedObjectContext *)managedObjectContext;

@end
