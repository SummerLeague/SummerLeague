//
//  SLPostImageResponse.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostImageResponse.h"

@implementation SLPostImageResponse

- (id)initWithResponseObject:(id)responseObject managedObjectContext:(NSManagedObjectContext *)managedObjectContext;
{
	self = [super init];
	if( self != nil )
	{
		[self parseResponseObject:responseObject withManagedObjectContext:managedObjectContext];
	}
	
	return self;
}

- (void)parseResponseObject:(id)responseObject withManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
{
	if( [responseObject isKindOfClass:[NSDictionary class]] )
	{
	}
}
@end
