//
//  User.h
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSManagedObject

@property (nonatomic, copy) NSString *rulingClassId;
@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSSet *posts;

+ (instancetype)userWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

+ (instancetype)findUserWithNickname:(NSString *)nickname inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

+ (NSString *)entityName;

@end
