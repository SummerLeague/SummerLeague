//
//  SLCameraViewController.h
//  Obey
//
//  Created by Mark Stultz on 1/24/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Barcode;

@interface SLCameraViewController : UIViewController

@property (nonatomic, strong) Barcode *barcode;

@end
