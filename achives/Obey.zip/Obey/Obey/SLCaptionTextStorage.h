//
//  SLCaptionTextStorage.h
//  Obey
//
//  Created by Mark Stultz on 1/27/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLCaptionTextStorage : NSTextStorage

@property (nonatomic, strong) NSTextCheckingResult *activeUsername;

- (NSTextCheckingResult *)usernameAtCharacterIndex:(CFIndex)index;

@end
