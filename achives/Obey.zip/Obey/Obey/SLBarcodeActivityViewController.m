//
//  SLBarcodeActivityViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/4/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLBarcodeActivityViewController.h"
#import "SLCameraViewController.h"
#import "SLPostViewController.h"
#import "SLUserActivityViewController.h"
#import "SLPostCollectionViewCell.h"
#import "SLRulingClassCache.h"
#import "Barcode.h"
#import "Post.h"
#import "SLPostUploadProgressCollectionViewCell.h"

@interface SLBarcodeActivityViewController () <SLPostUploadProgressCollectionViewCellDelegate>

@property (nonatomic, copy) NSString *selectedUsername;

@end

@implementation SLBarcodeActivityViewController

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationItem.title = self.barcode.barcode;
	
	[SLRulingClassCache.sharedCache postsForBarcode:self.barcode completion:^(NSArray *posts, NSError *error) {
		[SLRulingClassCache.sharedCache.persistenceStack save];
		
		NSManagedObjectContext *managedObjectContext = SLRulingClassCache.sharedCache.persistenceStack.managedObjectContext;
		NSFetchedResultsController *fetchedResultsController = [Post postsFetchedResultsControllerForBarcode:self.barcode inManagedObjectContext:managedObjectContext];
		[self setFetchedResultsController:fetchedResultsController];
	}];
}

- (void)viewDidAppear:(BOOL)animated {
	SLPostUploadProgressCollectionViewCell *dialogueView = [SLPostUploadProgressCollectionViewCell presentMostRecentInWindow:self.view.window];
	dialogueView.delegate = self;
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	self.barcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if( [segue.identifier isEqualToString:@"addPostSegue"] )
	{
		SLCameraViewController *viewController = [[segue.destinationViewController viewControllers] objectAtIndex:0];
		viewController.barcode = self.barcode;
	}
	else if( [segue.identifier isEqualToString:@"viewPostSegue"] )
	{
		SLPostViewController *viewController = segue.destinationViewController;
		viewController.post = self.selectedPost;
	}
	else if( [segue.identifier isEqualToString:@"viewUserSegue"] )
	{
		SLUserActivityViewController *viewController = segue.destinationViewController;
		viewController.username = self.selectedUsername;
	}
}

- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didTapOnUsername:(NSString *)username
{
	self.selectedUsername = username;
	[self performSegueWithIdentifier:@"viewUserSegue" sender:self];
}

#pragma mark - UploadProgressCollectionViewCell delegate methods
- (void)postUploadProgressCollectionViewCellUploadDidFinish:(SLPostUploadProgressCollectionViewCell *)cell {
	[cell dismiss];
}
@end
