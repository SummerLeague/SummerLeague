//
//  SLPostActivityViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/29/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostActivityViewController.h"
#import "SLFetchedResultsDataSource.h"
#import "SLPostCollectionViewCell.h"
#import "User.h"
#import "Post.h"
#import "SLRulingClassCache.h"

@interface SLPostActivityViewController () <SLPostCollectionViewCellDelegate, SLFetchedResultsDataSourceDelegate, UICollectionViewDelegateFlowLayout>

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) SLFetchedResultsDataSource *fetchedResultsDataSource;

@end

@implementation SLPostActivityViewController

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.collectionView.delegate = self;
}

- (void)setFetchedResultsController:(NSFetchedResultsController *)fetchedResultsController
{
	self.fetchedResultsDataSource = [[SLFetchedResultsDataSource alloc] initWithFetchedResultsController:fetchedResultsController collectionView:self.collectionView];
	self.fetchedResultsDataSource.delegate = self;
	self.fetchedResultsDataSource.reusableCellIdentifier = @"cell";
}

- (Post *)selectedPost
{
	return self.fetchedResultsDataSource.selectedItem;
}

#pragma mark SLPostCollectionViewCellDelegate

- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didTapOnUsername:(NSString *)username
{
	/**/
}

#pragma mark SLFetchedResultsDataSourceDelegate

- (void)configureCell:(id)cell withObject:(id)object
{
	Post *post = object;
	SLPostCollectionViewCell *postCell = cell;
	postCell.delegate = self;
	if( post.cdnUri )
	{
		[[SLRulingClassCache sharedCache] imageForCDNURL:post.cdnUri filename:post.file completion:^(UIImage *image) {
			postCell.postImageView.image = image;
		}];
	}
	
	postCell.captionTextView.textContainerInset = UIEdgeInsetsMake( 8.f, 4.f, 8.f, 4.f );
	
	if( !postCell.captionTextStorage.layoutManagers.count )
	{
		[postCell.captionTextStorage addLayoutManager:postCell.captionTextView.layoutManager];
	}
	
	NSString *captionText = [NSString stringWithFormat:@"%@ %@", ( post.creator.nickname ? post.creator.nickname : @"?" ), ( post.text ? post.text : @"" )];
	[postCell.captionTextStorage replaceCharactersInRange:NSMakeRange(0, postCell.captionTextStorage.length) withString:captionText];
}

- (void)deleteObject:(id)object
{
	/**/
}

#pragma mark UICollectionViewDelegateFlowLayout

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
	return 0.f;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section;
{
	return 0.f;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
	CGSize size = CGSizeMake( 320.0, 320.0 );
	
	SLCaptionTextStorage *captionTextStorage = [[SLCaptionTextStorage alloc] init];
	NSTextContainer *textContainer = [[NSTextContainer alloc] initWithSize:CGSizeMake( size.width, FLT_MAX )];
	NSLayoutManager *layoutManager = [[NSLayoutManager alloc] init];
	[layoutManager addTextContainer:textContainer];
	[captionTextStorage addLayoutManager:layoutManager];
	[textContainer setLineFragmentPadding:0.0];
	
	Post *post = [self.fetchedResultsDataSource itemAtIndexPath:indexPath];
	NSString *captionText = [NSString stringWithFormat:@"%@ %@", ( post.creator.nickname ? post.creator.nickname : @"?" ), ( post.text ? post.text : @"" )];
	[captionTextStorage replaceCharactersInRange:NSMakeRange(0, 0) withString:captionText];
	
	[layoutManager glyphRangeForTextContainer:textContainer];
	size.height += ceil( [layoutManager usedRectForTextContainer:textContainer].size.height );
	size.height += 8.0 + 8.0;	// UITextView's textContainerInset... we need to get this from IB.
	size.height += 32.0;			// Padding between posts
	
	return size;
}

@end
