//
//  SLProgressObserver.m
//  Obey
//
//  Created by Bradley Griffith on 1/27/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import "SLProgressObserver.h"

// KVO path strings for observing changes to properties of NSProgress
static NSString * const kProgressCancelledKeyPath          = @"cancelled";
static NSString * const kProgressCompletedUnitCountKeyPath = @"completedUnitCount";
static NSString * const kProgressKeyPath                   = @"fractionCompleted";

@implementation SLProgressObserver

- (id)initWithProgress:(NSProgress *)progress
{

	if ((self = [super init])) {
		_progress = progress;
		
		[_progress addObserver:self forKeyPath:kProgressCancelledKeyPath options:NSKeyValueObservingOptionNew context:NULL];
		[_progress addObserver:self forKeyPath:kProgressCompletedUnitCountKeyPath options:NSKeyValueObservingOptionNew context:NULL];
		[_progress addObserver:self forKeyPath:kProgressKeyPath options:NSKeyValueObservingOptionNew context:NULL];
	}
	return self;
}

- (void)dealloc
{
	[_progress removeObserver:self forKeyPath:kProgressCancelledKeyPath];
	[_progress removeObserver:self forKeyPath:kProgressCompletedUnitCountKeyPath];
	[_progress removeObserver:self forKeyPath:kProgressKeyPath];
	_progress = nil;
}

- (void)setDelegate:(id<SLProgressObserverDelegate>)delegate {
	// Let delegate know of current status
	_delegate = delegate;
	[_delegate observerDidChange:self];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	NSProgress *progress = object;
	// Check which KVO key change has fired
	if ([keyPath isEqualToString:kProgressCancelledKeyPath]) {
		// Notify the delegate that the progress was cancelled
		[self.delegate observerDidCancel:self];
	}
	else if ([keyPath isEqualToString:kProgressCompletedUnitCountKeyPath]) {
		// Notify the delegate of our progress change
		[self.delegate observerDidChange:self];
		if (progress.completedUnitCount == progress.totalUnitCount) {
			// Progress completed, notify delegate
			[self.delegate observerDidComplete:self];
		}
	}
}

@end
