//
//  SLCapturedPhotoViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <AssetsLibrary/AssetsLibrary.h>
#import "SLCapturedPhotoViewController.h"
#import "SLPostFinalizationViewController.h"
#import "Barcode.h"
#import "SLRulingClassCache.h"

@interface SLCapturedPhotoViewController ()

@property (nonatomic, weak) IBOutlet UIImageView *imageView;

- (IBAction)back:(id)sender;

@end

@implementation SLCapturedPhotoViewController

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self.navigationController setNavigationBarHidden:YES animated:NO];
	self.imageView.image = self.image;
}

- (void)encodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super encodeRestorableStateWithCoder:coder];
	
	if( self.image )
	{
		[coder encodeObject:UIImagePNGRepresentation( self.image ) forKey:@"image"];
	}
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	
	NSData *pngImageData = [coder decodeObjectForKey:@"image"];
	if( pngImageData )
	{
		self.image = [UIImage imageWithData:pngImageData];
	}
	
	self.barcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if( [segue.identifier isEqualToString:@"finalizePostSegue"] )
	{
		SLPostFinalizationViewController *viewController = segue.destinationViewController;
		viewController.barcode = self.barcode;
		viewController.postImage = self.image;
	}
}

- (IBAction)back:(id)sender
{
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)save:(id)sender
{
	ALAssetsLibrary *assetsLibrary = [[ALAssetsLibrary alloc] init];
	[assetsLibrary writeImageToSavedPhotosAlbum:self.image.CGImage orientation:(ALAssetOrientation)self.image.imageOrientation completionBlock:nil];
}

- (IBAction)share:(id)sender
{
	
}

@end

