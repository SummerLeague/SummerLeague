//
//  SLPostImageResponse.h
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SLPostImageResponse : NSObject

- (id)initWithResponseObject:(id)responseObject managedObjectContext:(NSManagedObjectContext *)managedObjectContext;
- (void)parseResponseObject:(id)responseObject withManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

@end
