//
//  SLBarcodeUtility.m
//  Obey
//
//  Created by Mark Stultz on 1/19/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLBarcodeUtility.h"
#import "RSUnifiedCodeGenerator.h"
#import "RSUnifiedCodeGenerator.h"
#import "RSCode39Generator.h"
#import "RSCode39Mod43Generator.h"
#import "RSExtendedCode39Generator.h"
#import "RSEAN13Generator.h"
#import "RSEAN8Generator.h"
#import "RSUPCEGenerator.h"
#import "RSCode93Generator.h"
#import "RSCode128Generator.h"
#import "Barcode.h"

@implementation SLBarcodeUtility

+ (NSString *)contentsForBarcode:(Barcode *)barcode
{
	if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeEAN13Code] )
	{
		RSEAN13Generator *codeGen = [[RSEAN13Generator alloc] init];
		return [codeGen completeBarcode:[codeGen barcode:barcode.barcode]];
	}
	else if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeUPCECode] )
	{
		RSUPCEGenerator *codeGen = [[RSUPCEGenerator alloc] init];
		return [codeGen completeBarcode:[codeGen barcode:barcode.barcode]];
	}
	else
	{
		return nil;
	}
}

+ (NSArray *)insetRangesForBarcode:(Barcode *)barcode
{
	if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeEAN13Code] )
	{
		return @[
			[NSValue valueWithRange:NSMakeRange( 11, 35 )],
			[NSValue valueWithRange:NSMakeRange( 49, 36 )],
		];
	}
	else if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeUPCECode] )
	{
		return @[ [NSValue valueWithRange:NSMakeRange( 3, 43 )] ];
	}
	else
	{
		return @[];
	}
}

+ (NSArray *)insetCodeRangesForBarcode:(Barcode *)barcode
{
	if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeEAN13Code] )
	{
		return @[
			[NSValue valueWithRange:NSMakeRange( 2, 5 )],
			[NSValue valueWithRange:NSMakeRange( 7, 5 )],
		];
	}
	else if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeUPCECode] )
	{
		return @[ [NSValue valueWithRange:NSMakeRange( 1, 6 )] ];
	}
	else
	{
		return @[];
	}
}

+ (NSArray *)insetCodeOffsetsForBarcode:(Barcode *)barcode
{
	if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeEAN13Code] )
	{
		return @[
			[NSValue valueWithCGRect:CGRectMake( 0.095f, 0.45f, 0.3775f, 0.55f )],
			[NSValue valueWithCGRect:CGRectMake( 0.5175f, 0.45f, 0.3775f, 0.55f )]
		];
	}
	else if( [barcode.barcodeType isEqualToString:AVMetadataObjectTypeUPCECode] )
	{
		return @[ [NSValue valueWithCGRect:CGRectMake( 0.095f, 0.45f, 0.77775f, 0.55f )] ];
	}
	else
	{
		return @[];
	}
}

@end
