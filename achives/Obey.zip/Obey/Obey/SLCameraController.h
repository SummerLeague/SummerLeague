//
//  SLCameraController.h
//  SLCameraViewController
//
//  Created by Bradley Griffith on 12/11/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SLCameraControllerDelegate;

@class AVCaptureSession;

@interface SLCameraController : NSObject

@property (nonatomic, strong, readonly) AVCaptureSession *session;
@property (nonatomic, weak) id<SLCameraControllerDelegate> delegate;

- (id)initWithMetadataCapture:(BOOL)metadataCapture stillImageCapture:(BOOL)stillImageCapture;

- (void)startCamera;
- (void)teardownCamera;

- (void)focusAndExposeAtPoint:(CGPoint)point;

- (void)captureImage:(void(^)(UIImage *image, NSError *error))completion;

@end

@protocol SLCameraControllerDelegate <NSObject>
@optional
- (void)cameraController:(SLCameraController *)cameraController didScanBarcodeType:(NSString *)barcodeType barcode:(NSString *)barcode;
@end
