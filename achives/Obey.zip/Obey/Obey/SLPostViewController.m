//
//  SLPostViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostViewController.h"
#import "SLCaptionTextStorage.h"
#import "UIImageView+AFNetworking.h"
#import "SLRulingClassCache.h"
#import "Post.h"
#import "User.h"

@interface SLPostViewController ()

@property (nonatomic, weak) IBOutlet UIImageView *postImageView;
@property (nonatomic, weak) IBOutlet UITextView *captionTextView;
@property (nonatomic, strong) SLCaptionTextStorage *captionTextStorage;

- (void)sharedInit;

@end

@implementation SLPostViewController

- (id)init
{
	self = [super init];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (void)sharedInit
{
	self.captionTextStorage = [[SLCaptionTextStorage alloc] init];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	self.captionTextView.textContainerInset = UIEdgeInsetsMake( 8.f, 4.f, 8.f, 4.f );
	[self.captionTextStorage addLayoutManager:self.captionTextView.layoutManager];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationItem.title = self.post.creator.nickname;
	
	if( self.post.cdnUri )
	{
		NSString *filename = [[NSString stringWithFormat:@"original_"] stringByAppendingString:( self.post.file ? self.post.file : @"" )];
		NSString *urlString = [self.post.cdnUri stringByAppendingPathComponent:filename];
		[self.postImageView setImageWithURL:[NSURL URLWithString:urlString]];
	}
	
	NSString *captionText = [NSString stringWithFormat:@"%@ %@", ( self.post.creator.nickname ? self.post.creator.nickname : @"?" ), ( self.post.text ? self.post.text : @"" )];
	[self.captionTextStorage replaceCharactersInRange:NSMakeRange( 0, self.captionTextStorage.length ) withString:captionText];
}

- (void)encodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super encodeRestorableStateWithCoder:coder];
	[coder encodeObject:self.post.rulingClassId forKey:@"post.rulingClassId"];
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	NSString *postRulingClassId = [coder decodeObjectForKey:@"post.rulingClassId"];
	if( postRulingClassId )
	{
		self.post = [Post postWithRulingClassId:postRulingClassId inManagedObjectContext:SLRulingClassCache.sharedCache.persistenceStack.managedObjectContext];
	}
}

@end
