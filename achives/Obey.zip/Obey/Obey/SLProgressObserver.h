//
//  SLProgressObserver.h
//  Obey
//
//  Created by Bradley Griffith on 1/27/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SLProgressObserverDelegate;

@interface SLProgressObserver : NSObject

@property (nonatomic, readonly) NSProgress *progress;
@property (nonatomic, weak) id<SLProgressObserverDelegate> delegate;

// Designated initializer
- (id)initWithProgress:(NSProgress *)progress;

@end

@protocol SLProgressObserverDelegate <NSObject>

- (void)observerDidChange:(SLProgressObserver *)observer;
- (void)observerDidCancel:(SLProgressObserver *)observer;
- (void)observerDidComplete:(SLProgressObserver *)observer;

@end