//
//  SLCameraController.m
//  Obey
//
//  Created by Bradley Griffith on 12/11/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "SLCameraController.h"

@interface SLCameraController () <AVCaptureMetadataOutputObjectsDelegate>

@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) dispatch_queue_t sessionQueue;
@property (nonatomic, strong) AVCaptureDeviceInput *videoDeviceInput;
@property (nonatomic, strong) AVCaptureMetadataOutput *metadataOutput;
@property (nonatomic, strong) AVCaptureStillImageOutput *stillImageOutput;

@property (nonatomic, strong) id runtimeErrorHandlingObserver;

- (void)setupCameraWithMetadataCapture:(BOOL)metadataCapture stillImageCapture:(BOOL)stillImageCapture;

- (BOOL)addVideoInput;
- (void)addMetadataOutput;
- (void)addStillImageOutput;

@end

@implementation SLCameraController

+ (AVCaptureDevice *)deviceWithMediaType:(NSString *)mediaType preferringPosition:(AVCaptureDevicePosition)position
{
	NSArray *devices = [AVCaptureDevice devicesWithMediaType:mediaType];
	AVCaptureDevice *captureDevice = devices.firstObject;
	
	for( AVCaptureDevice *device in devices )
	{
		if( device.position == position)
		{
			captureDevice = device;
			break;
		}
	}
	
	return captureDevice;
}

+ (void)setFlashMode:(AVCaptureFlashMode)flashMode forDevice:(AVCaptureDevice *)device
{
	if( device.hasFlash && [device isFlashModeSupported:flashMode] )
	{
		NSError *error = nil;
		if( [device lockForConfiguration:&error] )
		{
			device.flashMode = flashMode;
			[device unlockForConfiguration];
		}
		else
		{
			NSLog( @"SLCameraController: error in setFlashMode:forDevice: %@", error );
		}
	}
}

- (void)authorizeCameraPermissions;
{
	[AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
		if( !granted )
		{
			dispatch_async( dispatch_get_main_queue(), ^ {
				[[[UIAlertView alloc] initWithTitle:@"Could not use Camera"
													 message:@"This application does not have permission to use Camera, please change privacy settings."
													delegate:self
										cancelButtonTitle:@"OK"
									otherButtonTitles:nil] show];
			});
		}
	}];
}

- (void)setupCameraWithMetadataCapture:(BOOL)metadataCapture stillImageCapture:(BOOL)stillImageCapture {
	_session = [[AVCaptureSession alloc] init];

	[self authorizeCameraPermissions];

	_sessionQueue = dispatch_queue_create( "SLCameraController Session", DISPATCH_QUEUE_SERIAL );
	dispatch_async( _sessionQueue, ^ {
		[self addVideoInput];
		if( metadataCapture )
		{
			[self addMetadataOutput];
		}
		
		if( stillImageCapture )
		{
			[self addStillImageOutput];
		}
	});
}

- (BOOL)addVideoInput;
{
	BOOL success = NO;
	NSError *error = nil;
	AVCaptureDevice *videoDevice = [SLCameraController deviceWithMediaType:AVMediaTypeVideo preferringPosition:AVCaptureDevicePositionBack];
	_videoDeviceInput = [AVCaptureDeviceInput deviceInputWithDevice:videoDevice error:&error];
	
	if( !error )
	{
		if( [_session canAddInput:_videoDeviceInput] )
		{
			[_session addInput:_videoDeviceInput];
			success = YES;
		}
	}
	
	return success;
}

- (void)addMetadataOutput {
	_metadataOutput = [[AVCaptureMetadataOutput alloc] init];
	[_metadataOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
	[_session addOutput:_metadataOutput];
	_metadataOutput.metadataObjectTypes = _metadataOutput.availableMetadataObjectTypes;
}

- (void)addStillImageOutput
{
	_stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
	[_stillImageOutput setOutputSettings:@{AVVideoCodecKey : AVVideoCodecJPEG}];
	if ( [_session canAddOutput:_stillImageOutput] )
	{
		[_session addOutput:_stillImageOutput];
	}
}

- (void)startCamera {
	dispatch_async( _sessionQueue, ^ {
		__weak SLCameraController *weakSelf = self;
		_runtimeErrorHandlingObserver = [[NSNotificationCenter defaultCenter] addObserverForName:AVCaptureSessionRuntimeErrorNotification object:_sessionQueue queue:nil usingBlock:^(NSNotification *note) {
		SLCameraController *strongSelf = weakSelf;
		dispatch_async( strongSelf.sessionQueue, ^ {
			// Manually restarting the session since it must have been stopped due to an error.
			[strongSelf.session startRunning];
			});
		}];
		[_session startRunning];
	});
}

- (void)teardownCamera {
	dispatch_async( _sessionQueue, ^ {
		[_session stopRunning];
		[[NSNotificationCenter defaultCenter] removeObserver:_runtimeErrorHandlingObserver];
	});
}

- (void)focusAndExposeAtPoint:(CGPoint)point {
	dispatch_async( _sessionQueue, ^ {
		AVCaptureDevice *device = _videoDeviceInput.device;
		NSError *error = nil;

		if( [device lockForConfiguration:&error] )
		{
			if( device.isFocusPointOfInterestSupported && [device isFocusModeSupported:AVCaptureFocusModeAutoFocus] )
			{
				device.focusPointOfInterest = point;
				device.focusMode = AVCaptureFocusModeAutoFocus;
			}

			if( device.isExposurePointOfInterestSupported && [device isExposureModeSupported:AVCaptureExposureModeAutoExpose] )
			{
				device.exposurePointOfInterest = point;
				device.exposureMode = AVCaptureExposureModeAutoExpose;
			}

			[device unlockForConfiguration];
		}
		else
		{
			NSLog( @"SLCameraController: error in focusAndExposeTap: %@", error );
		}
	});
}

- (void)captureImage:(void(^)(UIImage *image, NSError *error))completion;
{
	if( !completion || !_stillImageOutput )
	{
		return;
	}
	
	dispatch_async( _sessionQueue, ^{
		//[AVCamViewController setFlashMode:AVCaptureFlashModeAuto forDevice:_videoDeviceInput.device];
		// Capture a still image.
		[_stillImageOutput captureStillImageAsynchronouslyFromConnection:[_stillImageOutput connectionWithMediaType:AVMediaTypeVideo]
																	  completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
			if( !imageDataSampleBuffer || error )
			{
				completion( nil, error );
			}
			else if( imageDataSampleBuffer )
			{
				NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
				UIImage *image = [[UIImage alloc] initWithData:imageData];
				completion( image, nil );
			}
		}];
	});
}

#pragma mark AVCaptureMetadataOutputObjectsDelegate

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection;
{
	NSArray *barCodeTypes = @[ AVMetadataObjectTypeUPCECode, AVMetadataObjectTypeCode39Code, AVMetadataObjectTypeCode39Mod43Code,
										AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode93Code, AVMetadataObjectTypeCode128Code,
										AVMetadataObjectTypePDF417Code, AVMetadataObjectTypeQRCode, AVMetadataObjectTypeAztecCode];
	
	for( AVMetadataObject *metadataObject in metadataObjects )
	{
		for( NSString *barCodeType in barCodeTypes )
		{
			if( [metadataObject.type isEqualToString:barCodeType] )
			{
				AVMetadataMachineReadableCodeObject *codeObject = (AVMetadataMachineReadableCodeObject *)metadataObject;
				if( [self.delegate respondsToSelector:@selector(cameraController:didScanBarcodeType:barcode:)] )
				{
					[self.delegate cameraController:self didScanBarcodeType:barCodeType barcode:codeObject.stringValue];
				}
			}
		}
	}
}

#pragma mark - lifecycle

- (id)initWithMetadataCapture:(BOOL)metadataCapture stillImageCapture:(BOOL)stillImageCapture
{
	self = [super init];
	if (self) {
		[self setupCameraWithMetadataCapture:metadataCapture stillImageCapture:stillImageCapture];
	}
	
	return self;
}


@end
