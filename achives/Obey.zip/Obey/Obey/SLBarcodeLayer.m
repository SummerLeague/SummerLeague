//
//  SLBarcodeLayer.m
//  Obey
//
//  Created by Mark Stultz on 1/19/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLBarcodeLayer.h"

@interface SLBarcodeLayer ()

- (CGMutablePathRef)createPathFromBarcode:(NSString *)barcode;

- (void)commonInit;

@end

@implementation SLBarcodeLayer

- (id)init
{
	self = [super init];
	if( self )
	{
		[self commonInit];
	}
	
	return self;
}

- (id)initWithLayer:(id)layer
{
	self = [super initWithLayer:layer];
	if( self )
	{
		[self commonInit];
	}
	
	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	if( self )
	{
		[self commonInit];
	}
	
	return self;
}

- (id)layer
{
	return [[SLBarcodeLayer alloc] init];
}

- (void)setContents:(id)contents
{
	self.path = [self createPathFromBarcode:contents];
}

- (void)commonInit
{
	self.shouldRasterize = YES;
	self.rasterizationScale = 2.f;
	self.minificationFilter = kCAFilterNearest;
	self.magnificationFilter = kCAFilterNearest;
	self.strokeColor = [UIColor blackColor].CGColor;
	self.insetRanges = @[];
}

- (CGMutablePathRef)createPathFromBarcode:(NSString *)barcode
{
	CGMutablePathRef path = CGPathCreateMutable();
	for( int ii = 0; ii < barcode.length; ++ii )
	{
		NSString *character = [barcode substringWithRange:NSMakeRange( ii, 1 )];
		if( [character isEqualToString:@"1"] )
		{
			CGPathMoveToPoint( path, nil, ii, 0);
			
			int y = self.bounds.size.height;
			for( NSValue *value in self.insetRanges )
			{
				NSRange range = value.rangeValue;
				if( ii >= range.location && ii < ( range.location + range.length ) )
				{
					y = self.insetHeight;
				}
			}
			
			CGPathAddLineToPoint( path, nil, ii, y );
		}
	}
	
	return path;
}

@end
