//
//  Post.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "Post.h"
#import "Barcode.h"
#import "User.h"
#import "SLRulingClassAPIClient.h"
#import "SLRulingClassCache.h"

@interface Post ()

+ (instancetype)findPostWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

@end

@implementation Post

@dynamic rulingClassId;
@dynamic creator;
@dynamic barcode;
@dynamic text;
@dynamic cdnUri;
@dynamic file;

+ (instancetype)postWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	Post *post = [Post findPostWithPredicate:[NSPredicate predicateWithFormat:@"rulingClassId = %@", rulingClassId] inManagedObjectContext:managedObjectContext];
	if( !post )
	{
		post = [NSEntityDescription insertNewObjectForEntityForName:self.entityName inManagedObjectContext:managedObjectContext];
		post.rulingClassId = rulingClassId;
	}
	
	return post;
}

+ (NSString *)entityName
{
	return @"Post";
}

+ (instancetype)findPostWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
{
	NSFetchRequest* request = [NSFetchRequest fetchRequestWithEntityName:self.entityName];
	request.predicate = predicate;
	NSArray *objects = [managedObjectContext executeFetchRequest:request error:nil];
	return objects.lastObject;
}

+ (NSFetchedResultsController *)postsFetchedResultsControllerForBarcode:(Barcode *)barcode inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	NSFetchRequest* request = [NSFetchRequest fetchRequestWithEntityName:self.entityName];
	request.predicate = [NSPredicate predicateWithFormat:@"barcode = %@", barcode];
	request.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"rulingClassId" ascending:NO]];
	return [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:nil];
}

+ (NSFetchedResultsController *)postsFetchedResultsControllerForUser:(User *)user inManagedObjetContext:(NSManagedObjectContext *)managedObjectContext
{
	NSFetchRequest* request = [NSFetchRequest fetchRequestWithEntityName:self.entityName];
	request.predicate = [NSPredicate predicateWithFormat:@"creator = %@", user];
	request.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"rulingClassId" ascending:NO]];
	return [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:nil];
}

@end
