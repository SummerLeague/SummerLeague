//
//  SLPostUploadProgressCell.h
//  Obey
//
//  Created by Bradley Griffith on 1/26/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLPostUploadProgressCell : UITableViewCell

@property (nonatomic, strong) NSProgress *progress;
@property (weak, nonatomic) IBOutlet UIProgressView *uploadProgressView;
@property (weak, nonatomic) IBOutlet UIImageView *postImage;
@property (weak, nonatomic) IBOutlet UILabel *uploadedMessage;

@end
