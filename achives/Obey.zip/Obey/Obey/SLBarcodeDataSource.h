//
//  SLBarcodeDataSource.h
//  Obey
//
//  Created by Mark Stultz on 1/4/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SLBarcodeDataSourceDelegate;

@class Barcode;

typedef NS_ENUM( NSInteger, BarcodeSectionIndex )
{
	BarcodeSectionIndexObjectId		= 0,
	BarcodeSectionIndexBarcode			= 1,
	BarcodeSectionIndexBarcodeType	= 2,
	BarcodeSectionIndexHits				= 3,
	MaxBarcodeSectionIndex,
};

@interface SLBarcodeDataSource : NSObject

@property (nonatomic, copy) NSString *reusableCellIdentifier;
@property (nonatomic, weak) id<SLBarcodeDataSourceDelegate> delegate;

- (id)initWithBarcode:(Barcode *)barcode tableView:(UITableView *)tableView;

@end

@protocol SLBarcodeDataSourceDelegate <NSObject>
@required
- (void)configureCell:(id)cell withBarcode:(Barcode *)barcode section:(NSInteger)section;
- (NSString *)titleForSection:(NSInteger)section;
@end