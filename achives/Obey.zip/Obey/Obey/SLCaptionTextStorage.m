//
//  SLCaptionTextStorage.m
//  Obey
//
//  Created by Mark Stultz on 1/27/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLCaptionTextStorage.h"

@interface SLCaptionTextStorage ()

@property (nonatomic, strong) NSMutableAttributedString *attributedString;
@property (nonatomic, strong) NSArray *usernames;

- (NSRegularExpression *)creatorRegularExpression;
- (NSRegularExpression *)usernameRegularExpression;
- (NSRegularExpression *)hashtagRegularExpression;

@end

@implementation SLCaptionTextStorage

- (id)init
{
	self = [super init];
	if( self )
	{
		self.attributedString = [[NSMutableAttributedString alloc] init];
		self.usernames = [NSArray array];
	}
	
	return self;
}

- (void)setActiveUsername:(NSTextCheckingResult *)activeUsername
{
	[self beginEditing];

	if( _activeUsername )
	{
		[self addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:_activeUsername.range];
	}

	_activeUsername = activeUsername;
	
	if( _activeUsername )
	{
		[self addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:_activeUsername.range];
	}
	
	[self endEditing];
}

- (NSTextCheckingResult *)usernameAtCharacterIndex:(CFIndex)index
{
	for( NSTextCheckingResult *result in self.usernames )
	{
		if( NSLocationInRange( index, result.range ) )
		{
			return result;
		}
	}
	
	return nil;
}

- (NSString *)string
{
	return self.attributedString.string;
}

- (NSDictionary *)attributesAtIndex:(NSUInteger)location effectiveRange:(NSRangePointer)range
{
	return [self.attributedString attributesAtIndex:location effectiveRange:range];
}

- (void)replaceCharactersInRange:(NSRange)range withString:(NSString *)aString
{
	[self beginEditing];
	[self.attributedString replaceCharactersInRange:range withString:aString];
	[self edited:NSTextStorageEditedCharacters range:range changeInLength:aString.length - range.length];
	[self endEditing];
}

- (void)setAttributes:(NSDictionary *)attrs range:(NSRange)range
{
	[self beginEditing];
	[self.attributedString setAttributes:attrs range:range];
	[self edited:NSTextStorageEditedAttributes range:range changeInLength:0];
	[self endEditing];
}

- (void)processEditing
{
	NSRange paragaphRange = [self.string paragraphRangeForRange:self.editedRange];
	[self removeAttribute:NSForegroundColorAttributeName range:paragaphRange];
	[self removeAttribute:NSFontAttributeName range:paragaphRange];
	[self removeAttribute:@"SLUsernameAttributeName" range:paragaphRange];
	
	self.usernames = @[];
	
	[self beginEditing];
	[self.creatorRegularExpression enumerateMatchesInString:self.string options:0 range:paragaphRange usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop) {
		NSRange usernameRange = [result rangeAtIndex:0];
		NSString *username = [self.attributedString.string substringWithRange:usernameRange];
		
		if( self.activeUsername && NSEqualRanges( self.activeUsername.range, usernameRange ) )
		{
			[self addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:result.range];
		}
		else
		{
			[self addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:result.range];
		}
		
		[self addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Helvetica Bold" size:14.0f] range:result.range];
		[self addAttribute:@"SLUsernameAttributeName" value:username range:result.range];
		[self edited:NSTextStorageEditedAttributes range:result.range changeInLength:0];

		NSMutableArray *mutableUsernames = [NSMutableArray arrayWithArray:self.usernames];
		[mutableUsernames addObject:result];
		self.usernames = [NSArray arrayWithArray:mutableUsernames];
	}];
	
	[self.usernameRegularExpression enumerateMatchesInString:self.string options:0 range:paragaphRange usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop) {
		if( self.activeUsername && NSEqualRanges( self.activeUsername.range, [result rangeAtIndex:0] ) )
		{
			[self addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:result.range];
		}
		else
		{
			[self addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:result.range];
		}
		
		NSRange usernameRange = [result rangeAtIndex:1];
		usernameRange.location += 1;
		usernameRange.length -= 1;
		NSString *username = [self.attributedString.string substringWithRange:usernameRange];
		
		[self addAttribute:@"SLUsernameAttributeName" value:username range:result.range];
		[self edited:NSTextStorageEditedAttributes range:result.range changeInLength:0];

		NSMutableArray *mutableUsernames = [NSMutableArray arrayWithArray:self.usernames];
		[mutableUsernames addObject:result];
		self.usernames = [NSArray arrayWithArray:mutableUsernames];
	}];
	
	[self endEditing];
/*
	[self.hashtagRegularExpression enumerateMatchesInString:self.string options:0 range:paragaphRange usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop) {
		[self addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:result.range];
	}];
*/
	
	[super processEditing];
}

- (NSRegularExpression *)creatorRegularExpression
{
	static NSRegularExpression *creatorRegularExpression = nil;
	static dispatch_once_t onceToken;
	dispatch_once( &onceToken, ^{
		creatorRegularExpression = [[NSRegularExpression alloc] initWithPattern:@"^\\w+" options:NSRegularExpressionCaseInsensitive error:nil];
	});
	
	return creatorRegularExpression;
}

- (NSRegularExpression *)usernameRegularExpression
{
	static NSRegularExpression *usernameRegularExpression = nil;
	static dispatch_once_t onceToken;
	dispatch_once( &onceToken, ^{
		usernameRegularExpression = [[NSRegularExpression alloc] initWithPattern:@"\\s(@\\w+)[. ?!]" options:NSRegularExpressionCaseInsensitive error:nil];
	});
	
	return usernameRegularExpression;
}

- (NSRegularExpression *)hashtagRegularExpression
{
	static NSRegularExpression *hashtagRegularExpression = nil;
	static dispatch_once_t onceToken;
	dispatch_once( &onceToken, ^{
		hashtagRegularExpression = [[NSRegularExpression alloc] initWithPattern:@"\\s(#\\w+)[. ?!]" options:NSRegularExpressionCaseInsensitive error:nil];
	});
	
	return hashtagRegularExpression;
}

@end
