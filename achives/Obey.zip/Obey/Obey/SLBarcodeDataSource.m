//
//  SLBarcodeDataSource.m
//  Obey
//
//  Created by Mark Stultz on 1/4/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLBarcodeDataSource.h"
#import "Barcode.h"

@interface SLBarcodeDataSource () <UITableViewDataSource>

@property (nonatomic, strong) Barcode *barcode;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation SLBarcodeDataSource

- (id)initWithBarcode:(Barcode *)barcode tableView:(UITableView *)tableView
{
	self = [super init];
	if( self )
	{
		self.barcode = barcode;
		self.tableView = tableView;
		self.tableView.dataSource = self;
	}
	
	return self;
}

#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	id cell = [tableView dequeueReusableCellWithIdentifier:self.reusableCellIdentifier forIndexPath:indexPath];
	[self.delegate configureCell:cell withBarcode:self.barcode section:indexPath.section];
	return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return MaxBarcodeSectionIndex;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	return self.delegate ? [self.delegate titleForSection:section] : @"";
}

@end
