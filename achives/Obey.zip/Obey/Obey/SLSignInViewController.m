//
//  SLSignInViewController.m
//  Obey
//
//  Created by Bradley Griffith on 1/15/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLSignInViewController.h"
#import "SLUserAuthenticator.h"
#import "SVProgressHUD.h"

@interface SLSignInViewController ()
@end

@implementation SLSignInViewController

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	// Show keyboad.
	[_nicknameField becomeFirstResponder];
}

// TODO: Determine which one of these is appropriate, if either, for executing code
// prior to all events that segue away from this controller.
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[self.view endEditing:YES];
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
	if( [segue.identifier isEqualToString:@"scannerSegue"] )
	{
		SLUserAuthenticator *authenticator = [[SLUserAuthenticator alloc] init];
		[authenticator loginWithStoredCredentials:^{} failure:^(NSString *errorMessage) {}];
	}
	
	[self.view endEditing:YES];
}

- (IBAction)signIn:(id)sender {
	[SVProgressHUD show];
	SLUserAuthenticator *authenticator = [[SLUserAuthenticator alloc] init];
	[authenticator loginWithNickname:_nicknameField.text
									password:_passwordField.text
									 success:^{
										 // Dismiss HUD.
										 [SVProgressHUD dismiss];
										 [self performSegueWithIdentifier:@"scannerSegue" sender:self];
									 }
									 failure:^(NSString *errorMessage) {
										 [SVProgressHUD showErrorWithStatus:errorMessage];
										 [_nicknameField becomeFirstResponder];
									 }];
}
@end
