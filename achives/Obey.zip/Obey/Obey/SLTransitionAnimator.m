//
//  SLTransitionAnimator.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLTransitionAnimator.h"

@implementation SLTransitionAnimator

- (NSTimeInterval)transitionDuration:(id <UIViewControllerContextTransitioning>)transitionContext
{
	return 0.f;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext
{
	UIViewController *toViewController = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
	UIView *container = transitionContext.containerView;
	
	if( [transitionContext transitionWasCancelled] )
	{
		[transitionContext completeTransition:NO];
	}
	else
	{
		[container addSubview:toViewController.view];
		[transitionContext completeTransition:YES];
	}
}

@end
