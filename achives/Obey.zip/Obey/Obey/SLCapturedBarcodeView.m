//
//  SLCapturedBarcodeView.m
//  Obey
//
//  Created by Mark Stultz on 1/19/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLCapturedBarcodeView.h"
#import "SLBarcodeLayer.h"
#import "SLBarcodeUtility.h"
#import "Barcode.h"

@interface SLCapturedBarcodeView ()

@property (nonatomic, strong) SLBarcodeLayer *codeLayer;
@property (nonatomic, strong) NSMutableArray *textLayers;

- (void)commonInit;

@end

@implementation SLCapturedBarcodeView

- (id)init
{
	self = [super init];
	if( self )
	{
		[self commonInit];
	}
	
	return self;
}

- (id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if( self )
	{
		[self commonInit];
	}

	return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	if( self )
	{
		[self commonInit];
	}
	
	return self;
}

- (void)commonInit
{
	self.layer.backgroundColor = [UIColor clearColor].CGColor;
	self.codeLayer = [SLBarcodeLayer layer];
	self.codeLayer.anchorPoint = CGPointMake( 0.f, 1.f );
	[self.layer addSublayer:self.codeLayer];

	NSMutableArray *textLayers = [[NSMutableArray alloc] init];
	for( int ii = 0; ii < 2; ++ii )
	{
		CATextLayer *textLayer = [CATextLayer layer];
		textLayer.contentsScale = 2.f;
		textLayer.alignmentMode = kCAAlignmentCenter;
		textLayer.fontSize = 27;
		textLayer.foregroundColor = [UIColor blackColor].CGColor;
		[textLayers addObject:textLayer];
	}
	self.textLayers = textLayers;
}

- (void)setBarcode:(Barcode *)barcode
{
	float width = self.bounds.size.width;
	float height = self.bounds.size.height;

	NSString *contents = [SLBarcodeUtility contentsForBarcode:barcode];

	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions];
	self.codeLayer.frame = CGRectMake( 0.f, 0.f, (float)contents.length, height * 0.775f );
	self.codeLayer.insetHeight = floor( height * 0.58f );
	self.codeLayer.insetRanges = [SLBarcodeUtility insetRangesForBarcode:barcode];
	self.codeLayer.contents = contents;
	self.codeLayer.transform = CATransform3DMakeScale( width / ( (float)contents.length ), 1.f, 1.f );
	[CATransaction commit];

	NSArray *insetCodeRanges = [SLBarcodeUtility insetCodeRangesForBarcode:barcode];
	NSArray *insetCodeOffsets = [SLBarcodeUtility insetCodeOffsetsForBarcode:barcode];
	NSAssert( insetCodeRanges.count == insetCodeOffsets.count, @"insetCodeRanges.count != insetCodeOffsets.count" );
	
	[self removeTextLayers];
	for( NSUInteger ii = 0; ii < insetCodeRanges.count; ++ii )
	{
		NSRange insetCodeRange = ( (NSValue *)insetCodeRanges[ ii ] ).rangeValue;
		CGRect insetCodeOffset = [insetCodeOffsets[ ii ] CGRectValue];
		
		if( ii < self.textLayers.count )
		{
			CATextLayer *textLayer = self.textLayers[ ii ];
			if( textLayer )
			{
				textLayer.frame = CGRectMake( insetCodeOffset.origin.x * width, insetCodeOffset.origin.y * height, insetCodeOffset.size.width * width, insetCodeOffset.size.height * height );
				
				NSUInteger maxIndex = insetCodeRange.location + insetCodeRange.length;
				if( maxIndex < barcode.barcode.length )
				{
					textLayer.string = [barcode.barcode substringWithRange:insetCodeRange];
				}
				
				[self.layer addSublayer:textLayer];
			}
		}
	}
	
	dispatch_async( dispatch_get_main_queue(), ^{
		[self setNeedsDisplay];
	});
}

- (void)removeTextLayers
{
	for( CATextLayer *textLayer in self.textLayers )
	{
		[textLayer removeFromSuperlayer];
	}
}

@end
