//
//  SLBarcodeUtility.h
//  Obey
//
//  Created by Mark Stultz on 1/19/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Barcode;

@interface SLBarcodeUtility : NSObject

+ (NSString *)contentsForBarcode:(Barcode *)barcode;
+ (NSArray *)insetRangesForBarcode:(Barcode *)barcode;
+ (NSArray *)insetCodeRangesForBarcode:(Barcode *)barcode;
+ (NSArray *)insetCodeOffsetsForBarcode:(Barcode *)barcode;

@end
