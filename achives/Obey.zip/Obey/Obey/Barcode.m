//
//  Barcode.m
//  Obey
//
//  Created by Mark Stultz on 12/30/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "Barcode.h"
#import "SLRulingClassAPIClient.h"
#import "SLRulingClassCache.h"

@interface Barcode ()

+ (instancetype)findBarcodeWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

@end

@implementation Barcode

@dynamic rulingClassId;
@dynamic barcode;
@dynamic barcodeType;
@dynamic hits;
@dynamic posts;

+ (instancetype)barcodeWithRulingClassId:(NSString *)rulingClassId inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	Barcode *barcode = [Barcode findBarcodeWithPredicate:[NSPredicate predicateWithFormat:@"rulingClassId = %@", rulingClassId] inManagedObjectContext:managedObjectContext];
	if( !barcode )
	{
		barcode = [NSEntityDescription insertNewObjectForEntityForName:self.entityName inManagedObjectContext:managedObjectContext];
		barcode.rulingClassId = rulingClassId;
	}
	
	return barcode;
}

+ (instancetype)barcodeWithCode:(NSString *)code type:(NSString *)type inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	Barcode *barcode = [Barcode findBarcodeWithPredicate:[NSPredicate predicateWithFormat:@"barcode = %@ AND barcodeType = %@", code, type] inManagedObjectContext:managedObjectContext];
	if( !barcode )
	{
		barcode = [NSEntityDescription insertNewObjectForEntityForName:self.entityName inManagedObjectContext:managedObjectContext];
		barcode.barcode = code;
		barcode.barcodeType = type;
	}
	
	return barcode;
}

+ (NSString *)entityName
{
	return @"Barcode";
}

+ (instancetype)findBarcodeWithPredicate:(NSPredicate *)predicate inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
	NSFetchRequest* request = [NSFetchRequest fetchRequestWithEntityName:@"Barcode"];
	request.predicate = predicate;
	NSArray *objects = [managedObjectContext executeFetchRequest:request error:nil];
	return objects.lastObject;
}

@end
