//
//  SLRulingClassCache.m
//  Obey
//
//  Created by Mark Stultz on 12/30/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "SLRulingClassCache.h"
#import "AFHTTPRequestOperation.h"
#import "SLRulingClassAPIClient.h"
#import "SLPostImageRequest.h"
#import "SLUploadProgressTask.h"
#import "Barcode.h"
#import "User.h"
#import "Post.h"
#import "Image.h"

@interface SLRulingClassCache ()

@property (nonatomic, strong) SLPersistenceStack *persistenceStack;
@property (nonatomic, strong) NSMutableArray *pendingRequests;
@property (nonatomic, strong) Barcode *lastScannedBarcode;

- (void)sharedInit;

- (NSURLSessionDataTask *)postsWithParams:(NSDictionary *)params completion:(void (^)(NSArray *posts, NSError *error))completion;

- (id <AFURLResponseSerialization>)imageResponseSerializer;

@end

@implementation SLRulingClassCache

+ (SLRulingClassCache *)sharedCache
{
	static SLRulingClassCache *sharedCache = nil;
	static dispatch_once_t onceToken;
	dispatch_once( &onceToken, ^{
		sharedCache = [[SLRulingClassCache alloc] init];
	});
	
	return sharedCache;
}

- (void)sharedInit;
{
	NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Obey" withExtension:@"momd"];
	self.persistenceStack = [[SLPersistenceStack alloc] initWithStoreURL:[SLPersistenceStack defaultStoreURL] modelURL:modelURL];
	self.pendingRequests = [[NSMutableArray alloc] init];
	self.pendingUploadTasks = [[NSMutableArray alloc] init];
	
	NSString *lastScannedBarcodeObjectID = [[NSUserDefaults standardUserDefaults] objectForKey:@"lastScannedBarcodeObjectID"];
	if( lastScannedBarcodeObjectID )
	{
		self.lastScannedBarcode = [self barcodeWithObjectID:lastScannedBarcodeObjectID];
	}
}

- (id)init
{
	self = [super init];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}


- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super init];
	if( self )
	{
		[self sharedInit];
	}
	
	return self;
}

- (void)saveUserDefaults
{
	NSString *lastScannedBarcodeObjectID = nil;
	if( self.lastScannedBarcode )
	{
		lastScannedBarcodeObjectID = self.lastScannedBarcode.objectID.URIRepresentation.absoluteString;
	}
	
	[[NSUserDefaults standardUserDefaults] setObject:lastScannedBarcodeObjectID forKey:@"lastScannedBarcodeObjectID"];
}

- (Barcode *)barcodeWithObjectID:(NSString *)objectID
{
	Barcode *barcode = nil;
	
	NSManagedObjectContext *managedObjectContext = self.persistenceStack.managedObjectContext;
	NSManagedObjectID *managedObjectID = [managedObjectContext.persistentStoreCoordinator managedObjectIDForURIRepresentation:[NSURL URLWithString:objectID]];
	if( managedObjectID )
	{
		NSError *error = nil;
		barcode = (Barcode *)[managedObjectContext existingObjectWithID:managedObjectID error:&error];
		if( error )
		{
			NSLog( @"Error: %@", error.localizedDescription );
			barcode = nil;
		}
	}
	
	return barcode;
}

- (Barcode *)barcodeWithCode:(NSString *)code type:(NSString *)type wantsLatest:(BOOL)wantsLatest;
{
	Barcode *barcode = [Barcode barcodeWithCode:code type:type inManagedObjectContext:self.persistenceStack.managedObjectContext];
	
	self.lastScannedBarcode = barcode;
	
	BOOL hasDataFromServer = ( barcode.rulingClassId == nil );
	if( ( !hasDataFromServer || wantsLatest ) && ![self.pendingRequests containsObject:barcode] )
	{
		[self.pendingRequests addObject:barcode];
		
		NSString *path = [[@"/barcodes" stringByAppendingPathComponent:type] stringByAppendingPathComponent:code];
		[[SLRulingClassAPIClient sharedClient] GET:path parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
			if( [responseObject isKindOfClass:[NSDictionary class]] )
			{
				NSString *barcodeCode = responseObject[ @"code" ];
				NSString *barcodeCodeType = responseObject[ @"code_type" ];
				Barcode *barcode = [Barcode barcodeWithCode:barcodeCode type:barcodeCodeType inManagedObjectContext:self.persistenceStack.managedObjectContext];
				barcode.rulingClassId = responseObject[ @"_id" ];
				barcode.hits = responseObject[ @"hits" ];
				
				[self.pendingRequests removeObject:barcode];
				[self.persistenceStack save];
			}
		} failure:^(NSURLSessionDataTask *task, NSError *error) {
			NSLog( @"error: %@", error.localizedDescription );
			[self.pendingRequests removeObject:barcode];
		}];
	}

	return barcode;
}

- (NSURLSessionDataTask *)postsForBarcode:(Barcode *)barcode completion:(void (^)(NSArray *posts, NSError *error))completion
{
	id params = @{ @"barcode_id": barcode.rulingClassId ?: @"" };
	return [self postsWithParams:params completion:completion];
}

- (NSURLSessionDataTask *)postsForUser:(User *)user completion:(void (^)(NSArray *posts, NSError *error))completion
{
	id params = @{ @"user_id": user.rulingClassId ?: @"" };
	return [self postsWithParams:params completion:completion];
}

- (void)postImage:(UIImage *)image caption:(NSString *)caption forBarcode:(Barcode *)barcode
{
	SLUploadProgressTask *task = [SLPostImageRequest postImage:image caption:caption barcode:barcode managedObjectContext:self.persistenceStack.managedObjectContext completion:^(NSError *error, SLUploadProgressTask *task, SLPostImageResponse *response) {
		if (error) {
			[task didEncounterError:error];
		}
		else {
			[task uploadDidComplete];
			[self.pendingUploadTasks removeObject:task];
		}
	}];
	
	[self.pendingUploadTasks addObject:task];
}

- (NSURLSessionDataTask *)postsWithParams:(NSDictionary *)params completion:(void (^)(NSArray *posts, NSError *error))completion
{
	NSURLSessionDataTask *task = [[SLRulingClassAPIClient sharedClient] GET:@"/posts" parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
		if( responseObject )
		{
			NSMutableArray *posts = [[NSMutableArray alloc] init];
			
			NSDictionary *responseDict = responseObject;
			for( NSDictionary *postDict in responseDict[ @"posts" ] )
			{
				NSDictionary *creatorDict = postDict[ @"creator" ];
				NSDictionary *barcodeDict = postDict[ @"barcode" ];
				NSDictionary *imageDict = postDict[ @"image" ];
				NSArray *files = imageDict[ @"files" ];
				
				User *user = [User userWithRulingClassId:creatorDict[ @"_id" ] inManagedObjectContext:self.persistenceStack.managedObjectContext];
				user.nickname = creatorDict[ @"nickname" ];
				
				Post *post = [Post postWithRulingClassId:postDict[ @"_id" ] inManagedObjectContext:self.persistenceStack.managedObjectContext];
				post.creator = user;
				post.barcode = [Barcode barcodeWithRulingClassId:barcodeDict[ @"_id" ] inManagedObjectContext:self.persistenceStack.managedObjectContext];
				post.text = postDict[ @"text" ];
				post.cdnUri = imageDict[ @"cdnUri" ];
				post.file = files.firstObject;
				
				[posts addObject:post];
			}
			
			if( completion )
			{
				completion( posts, nil );
			}
		}
	} failure:^(NSURLSessionDataTask *task, NSError *error) {
		NSLog( @"Error: %@", error.localizedDescription );
		if( completion )
		{
			completion( nil, nil );
		}
	}];
	
	return task;
}

- (void)imageForCDNURL:(NSString *)cdnURL filename:(NSString *)filename completion:(void (^)(UIImage *image))completion
{
	Image *image = [Image imageWithCDNURL:cdnURL filename:filename inManagedObjectContext:self.persistenceStack.managedObjectContext];
	NSAssert( image, @"Could not find Image with cdnURL: %@ and filename: %@.", cdnURL, filename );
	
	if( !image.imageData )
	{
		NSString *urlString = [cdnURL stringByAppendingPathComponent:[@"original_" stringByAppendingString:filename]];
		NSURL *url = [NSURL URLWithString:urlString];
		
		NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
		
		AFHTTPRequestOperation *imageRequestOperation = [[AFHTTPRequestOperation alloc] initWithRequest:urlRequest];
		imageRequestOperation.responseSerializer = self.imageResponseSerializer;
		[imageRequestOperation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
			if( [urlRequest.URL isEqual:operation.request.URL] )
			{
				UIImage *responseImage = responseObject;
				image.imageData = UIImagePNGRepresentation( responseImage );
				[self.persistenceStack save];
				if( completion )
				{
					completion( responseImage );
				}
			}
		} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
/*
			if( [urlRequest.URL isEqual:operation.request.URL] )
			{
				if( faiulre )
				{
					failure( urlRequest, operation.response, error );
				}
			}
*/
		}];
		
		[[[SLRulingClassAPIClient sharedClient] operationQueue] addOperation:imageRequestOperation];
	}
	else if( completion )
	{
		completion( [UIImage imageWithData:image.imageData] );
	}
}

- (id <AFURLResponseSerialization>)imageResponseSerializer
{
	static id <AFURLResponseSerialization> imageResponseSerializer = nil;
	static dispatch_once_t onceToken;
	dispatch_once( &onceToken, ^{
		imageResponseSerializer = [AFImageResponseSerializer serializer];
	});

	return imageResponseSerializer;
}

@end
