//
//  SLUploadProgressTask.h
//  Obey
//
//  Created by Bradley Griffith on 1/26/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SLUploadProgressTaskDelegate;

@interface SLUploadProgressTask : NSObject

@property (nonatomic, strong) NSURLSessionUploadTask *task;
@property (nonatomic, strong) NSProgress *progress;
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, weak) id<SLUploadProgressTaskDelegate> delegate;

- (void)didEncounterError:(NSError *)error;
- (void)uploadDidComplete;

@end

@protocol SLUploadProgressTaskDelegate <NSObject>

@optional
- (void)postUploadProgressTaskDidComplete:(SLUploadProgressTask *)progressTask;
- (void)postUploadProgressTask:(SLUploadProgressTask *)progressTask didFailWithError:(NSError *)error;

@end