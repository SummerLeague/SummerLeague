//
//  SLPostUploadProgressCollectionViewCell.m
//  Obey
//
//  Created by Bradley Griffith on 1/31/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostUploadProgressCollectionViewCell.h"
#import "SLProgressObserver.h"
#import "SLUploadProgressTask.h"
#import "SLRulingClassCache.h"
#import <QuartzCore/QuartzCore.h>

@interface SLPostUploadProgressCollectionViewCell () <SLProgressObserverDelegate, SLUploadProgressTaskDelegate>
@property SLProgressObserver *observer;
@end

@implementation SLPostUploadProgressCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		
		// Load nib and loop through objects so that we are certain we have a BGDialogueCollectionViewCell.
		NSArray* nibViews =  [[NSBundle mainBundle] loadNibNamed:@"SLPostUploadProgressCollectionViewCell" owner:self options:nil];
		for (id currentObject in nibViews) {
			if ([currentObject isKindOfClass:[SLPostUploadProgressCollectionViewCell class]]) {
				_view = (SLPostUploadProgressCollectionViewCell *) currentObject;
				break;
			}
		}
		[self addSubview:_view];
		
		_view.uploadProgressView.hidden = YES;
	}
	return self;
}

- (void)awakeFromNib {
	[super awakeFromNib];
	[self addSubview:_view];
}


+ (id)presentMostRecentInWindow:(UIWindow *)window {
	SLUploadProgressTask *pt = [[[SLRulingClassCache sharedCache] pendingUploadTasks] lastObject];
	if (pt) {
		// Create a prototype of our cell in order to get it's height... (TODO: Refactor).
		CGRect rect = CGRectMake(0, 0, window.frame.size.width, window.frame.size.height);
		SLPostUploadProgressCollectionViewCell *pv = [[SLPostUploadProgressCollectionViewCell alloc] initWithFrame:rect];
		
		// Adjust frame size and position just off screen.
		rect = CGRectMake(0, window.frame.size.height, window.frame.size.width, pv.view.frame.size.height);
		// TODO: Refactor. Why can't we just update the frame for the current dv here??
		pv = [[SLPostUploadProgressCollectionViewCell alloc] initWithFrame:rect];
		// TODO: Is last object appropriate? We want the last added.
		[pv setProgressTask:pt];
		[window addSubview:pv];
		
		[UIView animateWithDuration:0.3 animations:^{
			CGRect finalRect = pv.frame;
			finalRect.origin.y -= pv.frame.size.height;
			pv.frame = finalRect;
		}];
		
		return pv;
	}
	return nil;
}

- (void)setProgressTask:(SLUploadProgressTask *)progressTask {
	_progressTask = progressTask;
	_progressTask.delegate = self;
	_view.uploadProgressView.hidden = NO;
	_view.uploadProgressView.progress = 0.0f;
	_view.cancelButton.hidden = NO;
	_view.postImageThumbnail.image = _progressTask.image;
	_observer = [[SLProgressObserver alloc] initWithProgress:_progressTask.progress];
	_observer.delegate = self;
	
}

- (void)dismiss {
	[UIView animateWithDuration:0.3 animations:^{
		CGRect rect = self.frame;
		
		// position just off screen & account for shadow
		rect.origin.y += self.frame.size.height + 10;
		
		self.frame = rect;
	} completion:^(BOOL finished) {
		[self removeFromSuperview];
	}];
}


- (IBAction)cancel:(id)sender {
}

#pragma mark - ProgressObserver delegate methods

- (void)observerDidChange:(SLProgressObserver *)observer
{
	dispatch_async(dispatch_get_main_queue(), ^{
		// Update the progress bar with the latest completion %
		_view.uploadProgressView.progress = observer.progress.fractionCompleted;
		NSLog(@"progress changed completedUnitCount[%lld]", observer.progress.completedUnitCount);
	});
}

- (void)observerDidCancel:(SLProgressObserver *)observer
{
	NSLog(@"progress canceled");
}

- (void)observerDidComplete:(SLProgressObserver *)observer
{
	dispatch_async(dispatch_get_main_queue(), ^{
		//_uploadProgressView.hidden = YES;
		NSLog(@"progress complete");
	});
}


#pragma mark - UploadProgressTask delegate methods

- (void)postUploadProgressTaskDidComplete:(SLUploadProgressTask *)progressTask {
	_view.cancelButton.hidden = YES;
	_view.uploadProgressView.hidden = YES;
	_view.uploadStatusLabel.hidden = NO;
	_view.uploadStatusLabel.text = @"Finished";

	
	if( [self.delegate respondsToSelector:@selector(postUploadProgressCollectionViewCellUploadDidFinish:)] )
	{
		[self.delegate postUploadProgressCollectionViewCellUploadDidFinish:(SLPostUploadProgressCollectionViewCell *)self];
	}
}


- (void)postUploadProgressTask:(SLUploadProgressTask *)progressTask didFailWithError:(NSError *)error {
	_view.cancelButton.hidden = YES;
	_view.uploadProgressView.hidden = YES;
	_view.uploadStatusLabel.text = @"Problem encountered.";
}

@end
