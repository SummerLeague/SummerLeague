//
//  SLAccountCreationViewController.h
//  Obey
//
//  Created by Bradley Griffith on 1/14/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLAccountCreationViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *nicknameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;

- (IBAction)createAccount:(id)sender;

@end
