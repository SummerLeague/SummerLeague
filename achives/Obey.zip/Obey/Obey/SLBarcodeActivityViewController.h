//
//  SLBarcodeActivityViewController.h
//  Obey
//
//  Created by Mark Stultz on 1/4/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SLPostActivityViewController.h"

@class Barcode;

@interface SLBarcodeActivityViewController : SLPostActivityViewController

@property (nonatomic, strong) Barcode *barcode;

@end
