//
//  Image.h
//  Obey
//
//  Created by Mark Stultz on 1/30/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Image : NSManagedObject

@property (nonatomic, copy) NSString *cdnURL;
@property (nonatomic, copy) NSString *filename;
@property (nonatomic, retain) NSData *imageData;

+ (instancetype)imageWithCDNURL:(NSString *)cdnURL filename:(NSString *)filename inManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

+ (NSString *)entityName;

@end
