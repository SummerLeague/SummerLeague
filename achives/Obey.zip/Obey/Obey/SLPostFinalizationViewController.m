//
//  SLPostFinalizationViewController.m
//  Obey
//
//  Created by Bradley Griffith on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostFinalizationViewController.h"
#import "SLRulingClassCache.h"
#import "Barcode.h"

@interface SLPostFinalizationViewController ()

@property (weak, nonatomic) IBOutlet UITextView *postCaptionTextView;
@property (weak, nonatomic) IBOutlet UIImageView *postImagePreviewImageView;

- (IBAction)back:(id)sender;
- (IBAction)share:(id)sender;

@end

@implementation SLPostFinalizationViewController

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	[_postCaptionTextView  setTextContainerInset:UIEdgeInsetsMake(10, 80, 10, 10)];
	[_postImagePreviewImageView setImage:_postImage];
}

- (void)encodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super encodeRestorableStateWithCoder:coder];
	
	if( self.postImage )
	{
		[coder encodeObject:UIImagePNGRepresentation( self.postImage ) forKey:@"postImage"];
	}
	
	[coder encodeObject:_postCaptionTextView.text forKey:@"comment"];
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	
	NSData *pngImageData = [coder decodeObjectForKey:@"postImage"];
	if( pngImageData )
	{
		self.postImage = [UIImage imageWithData:pngImageData];
		[_postImagePreviewImageView setImage:_postImage];
	}
	
	_postCaptionTextView.text = [coder decodeObjectForKey:@"comment"];
	self.barcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
}

- (IBAction)back:(id)sender
{
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)share:(id)sender
{
	[[SLRulingClassCache sharedCache] postImage:_postImage caption:_postCaptionTextView.text forBarcode:_barcode];
	[self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

@end
