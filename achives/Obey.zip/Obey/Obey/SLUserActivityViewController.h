//
//  SLUserActivityViewController.h
//  Obey
//
//  Created by Mark Stultz on 1/26/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SLPostActivityViewController.h"

@interface SLUserActivityViewController : SLPostActivityViewController

@property (nonatomic, copy) NSString *username;

@end
