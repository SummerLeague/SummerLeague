//
//  SLPostUploadProgressCollectionViewCell.h
//  Obey
//
//  Created by Bradley Griffith on 1/31/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SLUploadProgressTask;

@protocol SLPostUploadProgressCollectionViewCellDelegate;

@interface SLPostUploadProgressCollectionViewCell : UICollectionViewCell

@property (nonatomic, retain) IBOutlet SLPostUploadProgressCollectionViewCell *view;
@property (nonatomic, strong) SLUploadProgressTask *progressTask;
@property (weak, nonatomic) IBOutlet UIImageView *postImageThumbnail;
@property (weak, nonatomic) IBOutlet UILabel *uploadStatusLabel;
@property (weak, nonatomic) IBOutlet UIProgressView *uploadProgressView;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (nonatomic, weak) id<SLPostUploadProgressCollectionViewCellDelegate> delegate;

+ (id)presentMostRecentInWindow:(UIWindow *)window;

- (IBAction)cancel:(id)sender;
- (void)dismiss;

@end

@protocol SLPostUploadProgressCollectionViewCellDelegate <NSObject>

@optional
- (void)postUploadProgressCollectionViewCellDidTapCell:(SLPostUploadProgressCollectionViewCell *)cell;
- (void)postUploadProgressCollectionViewCellUploadDidFinish:(SLPostUploadProgressCollectionViewCell *)cell;
- (void)postUploadProgressCollectionViewCellUploadDidFail:(SLPostUploadProgressCollectionViewCell *)cell;

@end
