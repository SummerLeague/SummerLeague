//
//  SLCredentialStore.m
//  Obey
//
//  Created by Bradley Griffith on 1/14/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLCredentialStore.h"
#import "SSKeychain.h"

#define SERVICE_NAME @"OBEY"
#define AUTH_TOKEN_KEY @"auth_token"
#define NICKNAME_KEY @"nickname"
#define ID_KEY @"userId"
#define PASSWORD_KEY @"password"

@implementation SLCredentialStore

- (BOOL)isLoggedIn {
	return [self authToken] != nil;
}

- (void)clearSavedCredentials {
	[self setAuthToken:nil];
	[self setNickname:nil];
	[self setPassword:nil];
	[self setUserId:nil];
}

- (NSString *)authToken {
	return [self secureValueForKey:AUTH_TOKEN_KEY];
}

- (NSString *)nickname {
	return [self secureValueForKey:NICKNAME_KEY];
}

- (NSString *)password {
	return [self secureValueForKey:PASSWORD_KEY];
}

- (NSString *)userId {
	return [self secureValueForKey:ID_KEY];
}

- (void)setAuthToken:(NSString *)authToken {
	[self setSecureValue:authToken forKey:AUTH_TOKEN_KEY];
	[[NSNotificationCenter defaultCenter] postNotificationName:@"token-changed" object:self];
}

- (void)setNickname:(NSString *)nickname {
	[self setSecureValue:nickname forKey:NICKNAME_KEY];
}

- (void)setPassword:(NSString *)password {
	[self setSecureValue:password forKey:PASSWORD_KEY];
}

- (void)setUserId:(NSString *)userId {
	[self setSecureValue:userId forKey:ID_KEY];
}

- (void)setSecureValue:(NSString *)value forKey:(NSString *)key {
	// In the keychain, there are passwords for various services.
	// We utilize these key/values to store sensitive key/value pairs.
	if (value) {
		[SSKeychain setPassword:value
						 forService:SERVICE_NAME
							 account:key];
	}
	else {
		[SSKeychain deletePasswordForService:SERVICE_NAME account:key];
	}
}

- (NSString *)secureValueForKey:(NSString *)key {
	return [SSKeychain passwordForService:SERVICE_NAME account:key];
}

@end