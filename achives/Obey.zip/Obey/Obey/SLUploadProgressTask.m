//
//  SLUploadProgressTask.m
//  Obey
//
//  Created by Bradley Griffith on 1/26/14.
//  Copyright (c) 2014 Mark Stultz. All rights reserved.
//

#import "SLUploadProgressTask.h"

@implementation SLUploadProgressTask

- (void)didEncounterError:(NSError *)error {
	if( [self.delegate respondsToSelector:@selector(didEncounterError:)] )
	{
		[self.delegate postUploadProgressTask:(SLUploadProgressTask *)self didFailWithError:(NSError *)error];
	}
}

- (void)uploadDidComplete {
	if( [self.delegate respondsToSelector:@selector(postUploadProgressTaskDidComplete:)] )
	{
		[self.delegate postUploadProgressTaskDidComplete:(SLUploadProgressTask *)self];
	}
}

@end
