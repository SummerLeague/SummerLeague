//
//  SLPostActivityViewController.h
//  Obey
//
//  Created by Mark Stultz on 1/29/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Post;

@interface SLPostActivityViewController : UIViewController

- (void)setFetchedResultsController:(NSFetchedResultsController *)fetchedResultsController;

- (Post *)selectedPost;

@end
