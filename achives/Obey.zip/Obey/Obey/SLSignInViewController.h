//
//  SLSignInViewController.h
//  Obey
//
//  Created by Bradley Griffith on 1/15/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLSignInViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *nicknameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;

- (IBAction)signIn:(id)sender;

@end
