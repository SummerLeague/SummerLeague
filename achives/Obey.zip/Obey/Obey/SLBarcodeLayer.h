//
//  SLBarcodeLayer.h
//  Obey
//
//  Created by Mark Stultz on 1/19/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface SLBarcodeLayer : CAShapeLayer

@property (nonatomic, copy) NSArray *insetRanges;
@property (nonatomic, assign) float insetHeight;

@end
