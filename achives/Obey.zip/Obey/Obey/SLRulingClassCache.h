//
//  SLRulingClassCache.h
//  Obey
//
//  Created by Mark Stultz on 12/30/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SLPersistenceStack.h"

@class Barcode;
@class User;
@class Image;

@interface SLRulingClassCache : NSObject

@property (nonatomic, strong, readonly) SLPersistenceStack *persistenceStack;
@property (nonatomic, strong, readonly) Barcode *lastScannedBarcode;
@property (nonatomic, strong) NSMutableArray *pendingUploadTasks;

+ (SLRulingClassCache *)sharedCache;

- (void)saveUserDefaults;

- (Barcode *)barcodeWithObjectID:(NSString *)objectID;
- (Barcode *)barcodeWithCode:(NSString *)code type:(NSString *)type wantsLatest:(BOOL)wantsLatest;

- (NSURLSessionDataTask *)postsForBarcode:(Barcode *)barcode completion:(void (^)(NSArray *posts, NSError *error))completion;
- (NSURLSessionDataTask *)postsForUser:(User *)user completion:(void (^)(NSArray *posts, NSError *error))completion;

- (void)postImage:(UIImage *)image caption:(NSString *)caption forBarcode:(Barcode *)barcode;

- (void)imageForCDNURL:(NSString *)cdnURL filename:(NSString *)filename completion:(void (^)(UIImage *image))completion;

@end
