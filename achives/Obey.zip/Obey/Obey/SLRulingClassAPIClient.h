//
//  SLRulingClassAPIClient.h
//  Obey
//
//  Created by Mark Stultz on 12/26/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "AFHTTPSessionManager.h"

@interface SLRulingClassAPIClient : AFHTTPSessionManager

+ (SLRulingClassAPIClient *)sharedClient;

@end
