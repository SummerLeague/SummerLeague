//
//  SLPostImageRequest.m
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLPostImageRequest.h"
#import "SLRulingClassAPIClient.h"
#import "SLUploadProgressTask.h"
#import "Barcode.h"

@implementation SLPostImageRequest

+ (SLUploadProgressTask *)postImage:(UIImage *)image caption:(NSString *)caption barcode:(Barcode *)barcode managedObjectContext:(NSManagedObjectContext *)managedObjectContext completion:(void (^)(NSError *error, SLUploadProgressTask *task, SLPostImageResponse *response))completion
{
	id params = @{
					  @"barcode": barcode.rulingClassId ?: @"",
					  @"text": caption ?: @""
					  };
	
   NSString *urlString = [[NSURL URLWithString:@"/posts" relativeToURL:[[SLRulingClassAPIClient sharedClient] baseURL]] absoluteString];
	NSMutableURLRequest *request = [[[SLRulingClassAPIClient sharedClient] requestSerializer] multipartFormRequestWithMethod:@"POST" URLString:urlString parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
		[formData appendPartWithFileData:UIImageJPEGRepresentation( image, 1.f )
											 name:@"image"
										fileName:@"photo.jpeg"
										mimeType:@"image/jpeg"];
	} error:nil];
	
	NSProgress *progress;
	SLUploadProgressTask *progressTask = [[SLUploadProgressTask alloc] init];
	NSURLSessionUploadTask *task = [[SLRulingClassAPIClient sharedClient] uploadTaskWithStreamedRequest:request progress:&progress completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
		SLPostImageResponse *postResponse = [[SLPostImageResponse alloc] initWithResponseObject:responseObject managedObjectContext:managedObjectContext];
		if( completion )
		{
			completion( nil, progressTask, postResponse );
		}
		if (error) {
			completion( error, nil, nil );
		}
	}];
	
	progressTask.task = task;
	progressTask.image = image;
	progressTask.progress = progress;
	
	[task resume];
	
	return progressTask;
}


@end