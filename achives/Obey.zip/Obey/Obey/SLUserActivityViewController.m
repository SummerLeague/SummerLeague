//
//  SLUserActivityViewController.m
//  Obey
//
//  Created by Mark Stultz on 1/26/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import "SLUserActivityViewController.h"
#import "SLPostViewController.H"
#import "SLFetchedResultsDataSource.h"
#import "SLRulingClassCache.h"
#import "SLPostCollectionViewCell.h"
#import "Post.h"
#import "User.h"
#import "Barcode.h"

@interface SLUserActivityViewController ()

@property (nonatomic, copy) NSString *selectedUsername;

@end

@implementation SLUserActivityViewController

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationItem.title = self.username;
	
	NSManagedObjectContext *managedObjectContext = SLRulingClassCache.sharedCache.persistenceStack.managedObjectContext;
	User *user = [User findUserWithNickname:self.username inManagedObjectContext:managedObjectContext];
	if( !user )
	{
		NSAssert( user, @"Didn't find user: %@", self.username );
	}
	
	[SLRulingClassCache.sharedCache postsForUser:user completion:^(NSArray *posts, NSError *error) {
		NSFetchedResultsController *fetchedResultsController = [Post postsFetchedResultsControllerForUser:user inManagedObjetContext:managedObjectContext];
		[self setFetchedResultsController:fetchedResultsController];
	}];
}

- (void)encodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super encodeRestorableStateWithCoder:coder];
	[coder encodeObject:self.username forKey:@"username"];
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	self.username = [coder decodeObjectForKey:@"username"];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if( [segue.identifier isEqualToString:@"viewPostSegue"] )
	{
		SLPostViewController *viewController = segue.destinationViewController;
		viewController.post = self.selectedPost;
	}
	else if( [segue.identifier isEqualToString:@"viewUserSegue"] )
	{
		SLUserActivityViewController *viewController = segue.destinationViewController;
		viewController.username = self.selectedUsername;
	}
}

- (void)postCollectionViewCell:(SLPostCollectionViewCell *)cell didTapOnUsername:(NSString *)username
{
	self.selectedUsername = username;
	[self performSegueWithIdentifier:@"viewUserSegue" sender:self];
}

@end
