//
//  SLPostViewController.h
//  Obey
//
//  Created by Mark Stultz on 1/25/14.
//  Copyright (c) 2014 Summer League. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Post;

@interface SLPostViewController : UIViewController

@property (nonatomic, strong) Post *post;

@end
