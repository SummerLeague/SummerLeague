//
//  SLScannerViewController.m
//  Obey
//
//  Created by Mark Stultz on 12/26/13.
//  Copyright (c) 2013 Summer League. All rights reserved.
//

#import "SLScannerViewController.h"
#import "SLBarcodeActivityViewController.h"
#import "SLCameraController.h"
#import "SLCapturedCodeViewController.h"
#import "SLRulingClassCache.h"
#import "SLCredentialStore.h"
#import "Barcode.h"

static void *BarcodeHitsContext = &BarcodeHitsContext;

@interface SLScannerViewController () <SLCameraControllerDelegate>

@property (nonatomic, strong) SLCapturedCodeViewController *capturedCodeViewController;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;
@property (nonatomic, strong) SLCameraController *cameraController;
@property (nonatomic, strong) Barcode *lastScannedBarcode;

- (void)setupPreviewLayer;
- (void)updateHitCountLabel;
- (void)addTapGestureRecognizer;
- (void)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer;

@end

@implementation SLScannerViewController

- (void)viewDidLoad;
{
	[super viewDidLoad];
		
	[self addTapGestureRecognizer];
	
	self.cameraController = [[SLCameraController alloc] initWithMetadataCapture:YES stillImageCapture:NO];
	self.cameraController.delegate = self;
	
	[self setupPreviewLayer];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[self.cameraController startCamera];
}

- (void)dealloc
{
	[_lastScannedBarcode removeObserver:self forKeyPath:@"hits"];
}

- (void)encodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super encodeRestorableStateWithCoder:coder];
	
	[[SLRulingClassCache sharedCache] saveUserDefaults];
}

- (void)decodeRestorableStateWithCoder:(NSCoder *)coder
{
	[super decodeRestorableStateWithCoder:coder];
	
	self.lastScannedBarcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
	if( self.lastScannedBarcode )
	{
		self.capturedCodeViewController.barcode = self.lastScannedBarcode;
		self.capturedCodeViewController.hits = [NSString stringWithFormat:NSLocalizedString( @"%@ Times", @"The first time you scan an item" ), self.lastScannedBarcode.hits.stringValue];
		self.capturedCodeViewController.busy = NO;
	}
}

- (BOOL)shouldAutorotate;
{
	return NO;
}

- (NSUInteger)supportedInterfaceOrientations
{
	return UIInterfaceOrientationPortrait;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if( [segue.identifier isEqualToString:@"scannedBarcodeSegue"] )
	{
		[[SLRulingClassCache sharedCache] saveUserDefaults];
		SLBarcodeActivityViewController *viewController = segue.destinationViewController;
		viewController.barcode = _lastScannedBarcode;
		
		[self.cameraController teardownCamera];
	}
	else if( [segue.identifier isEqualToString:@"embedCapturedCodeSegue"] )
	{
		self.capturedCodeViewController = segue.destinationViewController;
	}
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	if( context == BarcodeHitsContext )
	{
		[self updateHitCountLabel];
	}
	else
	{
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

- (void)setLastScannedBarcode:(Barcode *)lastScannedBarcode
{
	if( _lastScannedBarcode != lastScannedBarcode )
	{
		[_lastScannedBarcode removeObserver:self forKeyPath:@"hits"];
		_lastScannedBarcode = lastScannedBarcode;
		[_lastScannedBarcode addObserver:self forKeyPath:@"hits" options:NSKeyValueObservingOptionNew context:BarcodeHitsContext];
	}
}

- (IBAction)capturedCodeTapped:(id)sender
{
	if( self.lastScannedBarcode )
	{
		[self performSegueWithIdentifier:@"scannedBarcodeSegue" sender:self];
	}
}

- (void)setupPreviewLayer
{
	float minSize = MIN( self.view.bounds.size.width, self.view.bounds.size.height );
	CGRect bounds = CGRectMake( 0.f, 0.f, minSize, minSize );
	self.previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.cameraController.session];
	self.previewLayer.bounds = bounds;
	self.previewLayer.position = CGPointMake( CGRectGetMidX( self.view.bounds ), CGRectGetMidY( self.view.bounds ) );
	self.previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
	[self.view.layer addSublayer:self.previewLayer];
}

- (void)updateHitCountLabel
{
	self.capturedCodeViewController.busy = NO;
	
	BOOL isFirstHit = self.lastScannedBarcode.hits.intValue <= 1;
	if( isFirstHit )
	{
		self.capturedCodeViewController.hits = NSLocalizedString( @"First Hit!", @"The first time you scan an item" );
	}
	else
	{
		self.capturedCodeViewController.hits = [NSString stringWithFormat:NSLocalizedString( @"%@ Times", @"The first time you scan an item" ), self.lastScannedBarcode.hits.stringValue];
	}
}

- (void)addTapGestureRecognizer
{
	 // Add a single tap gesture to focus on the point tapped, then lock focus
	 UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(focusAndExposeTap:)];
	 [singleTap setNumberOfTapsRequired:1];
	 [self.view addGestureRecognizer:singleTap];
}

- (void)focusAndExposeTap:(UIGestureRecognizer *)gestureRecognizer
{
	CGPoint focusPoint = [self.previewLayer captureDevicePointOfInterestForPoint:[gestureRecognizer locationInView:[gestureRecognizer view]]];
	[self.cameraController focusAndExposeAtPoint:focusPoint];
}

- (IBAction)signOff:(id)sender
{
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:@"FirstRun"];
	[[[SLCredentialStore alloc] init] clearSavedCredentials];
	[self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark SLCameraControllerDelegate

- (void)cameraController:(SLCameraController *)cameraController didScanBarcodeType:(NSString *)barcodeType barcode:(NSString *)barcode
{
	Barcode *lastScannedBarcode = SLRulingClassCache.sharedCache.lastScannedBarcode;
	if( !self.lastScannedBarcode
		|| ![lastScannedBarcode.barcode isEqualToString:barcode]
		|| ![lastScannedBarcode.barcodeType isEqualToString:barcodeType] )
	{
		self.lastScannedBarcode = [SLRulingClassCache.sharedCache barcodeWithCode:barcode type:barcodeType wantsLatest:YES];
		self.capturedCodeViewController.barcode = self.lastScannedBarcode;
		self.capturedCodeViewController.busy = YES;
	}
}

@end
