function notFound(req, res) {
  res.send(404);
}

module.exports = {
  notFound: notFound
};
