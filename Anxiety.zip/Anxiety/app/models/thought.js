var mongoose = require('mongoose'),
    Imager = require('imager'),
		Schema = mongoose.Schema,
		extend = require('node.extend'),
    imagerConfig = require('config').imager;

/*
var ThoughtSchema = new Schema({
  image: {
    cdnUri: { type: String },
    files: []
  },
	createdAt: { type : Date, default : Date.now }
});
*/
var ThoughtSchema = new Schema({
  text: { type: String, default: '', trim: true, required: true }
});

/*
  Hooks.
*/
/*
ThoughtSchema.pre('remove', function (next) {
  var imager = new Imager(imagerConfig, 'S3'),
      files = this.image.files;

  // if there are files associated with the item, remove from S3 too
  imager.remove(files, function (err) {
    if (err) {
      return next(err);
    }
  }, 'thought');

  next();
});
*/

/*
	Class methods.
*/
ThoughtSchema.statics = extend({

  loadLast: function (id, callback) {
    this.findOne({}, {}, { sort: { 'created_at' : -1 } }, callback);
  }

}, ThoughtSchema.statics);


/*
  Instance methods.
*/
/*
ThoughtSchema.methods = extend({

  // Save an article and upload image if present.
  uploadAndSave: function (images, callback) {


      var self = this,
          imager = new Imager(imagerConfig, 'S3');

      this.validate(function (err) {
        if (err) {
          return callback(err, null);
        }
        if (!images || !images.length) {
          return self.save(function(err, thought) {
            if (thought) {
              self.model('Thought').collection.remove({}, function(err) {
                callback(err, thought);
              });
            }
            else {
              callback(err, thought);
            }
          });
        }
        else {
          imager.upload([images], function (err, cdnUri, files) {
            if (err) {
              return callback(err, null);
            }
            if (files.length) {
              self.image = { cdnUri : cdnUri, files : files }
            }
            self.save(function(err, thought) {
              if (thought) {
                self.model('Thought').collection.remove({}, function(err) {
                  callback(err, thought);
                });
              }
              else {
                callback(err, thought);
              }
            });
          }, 'thought');
        }
      });

  }

}, ThoughtSchema.methods);
*/


module.exports = mongoose.model('Thought', ThoughtSchema);
