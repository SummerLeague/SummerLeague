module.exports = function(app) {
  return {

    locals: {

      scripts: [],

      renderScriptsTags: function (all) {
        app.locals.scripts = [];
        if (all != undefined) {
          return all.map(function(script) {
            return '<script src="/assets/javascripts/' + script + '"></script>';
          }).join('\n ');
        }
        else {
          return '';
        }
      },

      getScripts: function(req, res) {
        return scripts;
      }

    }

  }
};
