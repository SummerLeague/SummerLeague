var Thought = require('app/models/thought');

function setup(app, io) {
  io.sockets.on('connection', function (socket) {
	  socket.on('send_image', function (data) {
	  	io.sockets.emit('image_broadcast', { image_data: data });
	  });
	});
}

module.exports = setup;
