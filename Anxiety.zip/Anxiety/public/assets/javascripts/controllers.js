'use strict';

/* Controllers */

var paneControllers = angular.module('paneControllers', []);

paneControllers.controller('PanesController', ['$scope',
  function($scope) {
    console.log('test');
  }]);

paneControllers.controller('PanesNewController', ['$scope',
  function($scope) {

  }]);
