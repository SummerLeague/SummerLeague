'use strict';

/* App Module */

var paneApp = angular.module('paneApp', [
  'ngRoute',
  'paneControllers'
]);

paneApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/panes', {
        templateUrl: 'partials/panes/index.html',
        controller: 'PanesController'
      }).
      when('/panes/new', {
        templateUrl: 'partials/panes/new.html',
        controller: 'PanesNewController'
      }).
      otherwise({
        redirectTo: '/'
      });
  }]);
