$(document).ready(function() {


  var AnxiousChat = {};

  AnxiousChat.Home = {
    init: function() {
      this.$layered_content_container = $('#layered-content');
      this.$join_layer = this.$layered_content_container.find('#join-layer');
      this.$room_layer = this.$layered_content_container.find('#room-layer');
      this.$room_canvas = this.$room_layer.find('canvas');
      this.$compose_layer = this.$layered_content_container.find('#compose-layer');
      this.$compose_video_output = this.$compose_layer.find('#compose-video-output');
      this.socket;
      this.server_address = 'http://38f09fd5.ngrok.com';
      this.connected = false;
      this.streaming = false;
      this.media_width = 420;
      this.media_height;
      this.local_media_stream = null;

      this.initializeViews();
      this.setupListeners();
    },
    setupListeners: function() {
      var self = this;
      this.$join_layer.find('button').on('click', function(e) { self.connect(e); });
      this.$room_layer.find('a#compose-link').on('click', function(e) { self.captureDeviceStream(e); });
      this.$compose_layer.find('button').on('click', function(e) { self.submitImage(e); });
      this.$compose_video_output.on('canplay', function(e) { self.resizeCanvas(e); });
    },
    initializeViews: function() {
      // We will also do this with CSS just to be really clear.
      this.$join_layer.show();
      this.$compose_layer.hide();
      this.$room_layer.hide();
    },
    connect: function(event) {
      var self = this;
      if (event) {
        event.preventDefault();
      }
      this.socket = io.connect(this.server_address);
      this.socket.on('connecting', function () {
        self.$join_layer.find('#connection-status-message').text('Connecting...');
      });
      this.socket.on('connect', function () {
        self.$join_layer.find('#connection-status-message').text('');
        self.connected = true;
        self.$join_layer.hide();
        self.$room_layer.show();
        self.$compose_layer.hide();
      });
      this.socket.on('connect_failed', function () {
        self.connected = false;
        self.$join_layer.show();
        self.$room_layer.hide();
        self.$compose_layer.hide();
        self.$join_layer.find('#connection-status-message').text('Connection failed. :(');
      });
      this.socket.on('error', function(data) {
        self.displayErrorWithMessage(data.message);
      });
      this.socket.on('disconnect', function () {
        self.connected = false;
        self.$join_layer.show();
        self.$room_layer.hide();
        self.$compose_layer.hide();
        self.$join_layer.find('#connection-status-message').text('Disconnected.');
      });
      this.socket.on('reconnecting', function () {
        self.$join_layer.find('#connection-status-message').text('Reconnecting...');
      });
      this.socket.on('reconnect_failed', function () {
        self.$join_layer.find('#connection-status-message').text('Failed to reconnect.');
      })
      this.socket.on('image_broadcast', function (data) {
        window.image_data = data;
        self.drawImageToCanvasWithData(data.image_data);
      });
    },
    resizeCanvas: function(event) {
      if (!this.streaming) {
        this.media_height = this.$compose_video_output[0].videoHeight / (this.$compose_video_output[0].videoWidth/this.media_width);

        this.$compose_video_output[0].setAttribute('width', this.media_width);
        this.$compose_video_output[0].setAttribute('height', this.media_height);
        this.$room_canvas[0].setAttribute('width', this.media_width);
        this.$room_canvas[0].setAttribute('height', this.media_height);
        this.streaming = true;
      }
    },
    drawImageToCanvasWithData: function(data) {
      var self = this;

      var img = new Image;
      img.onload = function(){
        console.log('loaded');
        self.$room_canvas[0].getContext('2d').drawImage(img, 0, 0);
      };
      img.src = data.image;
    },
    captureDeviceStream: function(event) {
      var self = this;

      if (event) {
        event.preventDefault();
      }

      this.$join_layer.hide();
      this.$room_layer.hide();
      this.$compose_layer.show();

      navigator.getUserMedia  = navigator.getUserMedia ||
                          navigator.webkitGetUserMedia ||
                          navigator.mozGetUserMedia ||
                          navigator.msGetUserMedia;

      var errorCallback = function(e) {
        var message = navigator.getUserMedia ? 'You must give me access to your camera.' : 'I can\'t find a camera on your device. :(';

        self.displayErrorWithMessage(message);

        self.$join_layer.hide();
        self.$room_layer.show();
        self.$compose_layer.hide();
      };

      if (navigator.getUserMedia) {
        navigator.getUserMedia({audio: false, video: true}, function(stream) {
          self.local_media_stream = stream;
          window.URL.createObjectURL(stream);
          if (navigator.mozGetUserMedia) {
            self.$compose_video_output[0].mozSrcObject = stream;
          } else {
            var vendorURL = window.URL || window.webkitURL;
            self.$compose_video_output[0].src = vendorURL.createObjectURL(stream);
          }
        }, errorCallback);
      } else {
        errorCallback();
      }
    },
    submitImage: function(event) {
      var self = this;
      if (event) {
        event.preventDefault();
      }

      if (this.local_media_stream) {
        this.$room_canvas[0].getContext('2d').drawImage(this.$compose_video_output[0], 0, 0, this.media_width, this.media_height);
        var data = this.$room_canvas[0].toDataURL("image/jpeg");
        this.socket.emit('send_image', { image: data });
      }
      this.$join_layer.hide();
      this.$room_layer.show();
      this.$compose_layer.hide();
    },
    displayErrorWithMessage: function(message) {
      var message = message || 'An error occured.';
      alert(message);
    }
  }
  AnxiousChat.Home.init();
});
