module.exports = {
  express: {
    port: process.env.PORT || 5000
  },
  database: {
    uri: process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/anxiety'
  },

  imager: {
		variants: {
	    thought: {
	      resize: {
	        original: "100%"
	      }
	    }
	  },
		storage: {
			S3: {
	      key: process.env.S3_KEY,
	      secret: process.env.S3_SECRET,
	      bucket: process.env.S3_BUCKET,
	      region: 'us-standard'
	    }
		},
		debug: true
	}
}
