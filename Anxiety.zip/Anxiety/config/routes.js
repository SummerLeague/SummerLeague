module.exports = function(app, io) {

  // Load all api routes
  [
    'home'
  ].forEach(function (routeName) {
      require("app/routes/" + routeName)(app, io);
  });

  // OK, routes are loaded, now use the router:
  app.use(app.router);


  app.get('*', function(req, res) {
    res.sendfile('./public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
  });

  // Finally, use any error handlers
  app.use(require("app/middleware/").notFound);
};
