Authentication with a server from your app.
------

Hello

This project will allow you to authenticate with a server and retrieve a protected message via a client app.

*NOTE: I wrote the files in this repo before we had a name... therefore there are no SummerLeague or SL references. This is just a sample app so Im not going to waste the time it would take to fix this terrible issue.*
