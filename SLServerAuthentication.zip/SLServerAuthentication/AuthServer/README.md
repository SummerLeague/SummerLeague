AuthServer
-----
A simple example server for authenticating over a RESTful API.