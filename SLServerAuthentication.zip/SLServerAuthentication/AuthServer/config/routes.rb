AuthServer::Application.routes.draw do
  scope :format => true, :constraints => { :format => 'json' } do

    get  'logout/', to: 'sessions#destroy'

    post 'settings/', to: "users#update"

    get 'secrets', to: 'secrets#show'

  end

  # NOTE: The following route, while used by any providers, i.e.; Facebook,
  #   with OmniAuth, can be confusing with OmniAuth Identity. When we are logging
  #   in a user, we will POST directly to this route. When we are signing up a
  #   user, we will POST to 'auth/identity/register'. After OmniAuth does its thing
  #   the auth hash will be POSTed back to this callback route. Our session#create
  #   action will then determine if it should also create a new user.
  #
  # NOTE: When POSTing to auth/identity/callback (login), the two parameters are 'auth_key'
  #   and 'password'. 'auth_key' will be the user's 'name' in our case (see
  #   app/db/identity.rb).
  #
  # NOTE: When POSTing to auth/identity/register (registration), the required parameters
  #   are 'name', 'email', 'password', and 'password_confirmation'.
  match "/auth/:provider/callback", to: "sessions#create"
  match "/auth/failure", to: "sessions#failure"
end
