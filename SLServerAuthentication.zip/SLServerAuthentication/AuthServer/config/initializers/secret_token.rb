# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AuthServer::Application.config.secret_token = 'd5a59578621e0771bd481a540bb60c15badc11e83c17f8040f31c07372f3aae29a509009251a36223a20445c46ad32bea626829cc8392599b7c3fa91171d14b5'
