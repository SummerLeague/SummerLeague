OmniAuth.config.logger = Rails.logger

Rails.application.config.middleware.use OmniAuth::Builder do
	provider :facebook, ENV['FACEBOOK_KEY'], ENV['FACEBOOK_SECRET']
  provider :identity, :fields => [:name, :email], :on_failed_registration => lambda { |env|
    SessionsController.action(:failure).call(env)
  }
end

# NOTE: By default, OmniAuth 1.1.0 and later raises an exception
#   in development mode when authentication fails. If you'd prefer
#   it to redirect to a failure page instead, uncomment the following:
OmniAuth.config.on_failure = Proc.new { |env|
  SessionsController.action(:failure).call(env)
}