class CreateAccessTokens < ActiveRecord::Migration
	def self.up
	  create_table :access_tokens do |t|
	    t.string    :token,            :null => false
	    t.datetime  :token_expires_at, :default => nil

	    t.integer   :tokenable_id
	    t.string    :tokenable_type
	  end
	end

  def self.down
  	drop_table :access_tokens
  end
end