class CreateProviderIdentities < ActiveRecord::Migration
  def self.up
    create_table :provider_identities do |t|
      t.belongs_to :user

      t.string :provider
      t.string :uid

      t.timestamps
    end
    add_index :provider_identities, :user_id
  end

  def self.down
    drop_table :provider_identities
  end
end