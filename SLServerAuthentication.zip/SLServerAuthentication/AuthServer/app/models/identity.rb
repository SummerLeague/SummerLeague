# Identity
#   Manages authentication with the 'omniauth-identity' provider for OmniAuth.
#   This allows for custom logins for our app for users that don't wish to
#   authenticate through a third party like Facebook or Twitter.
#
#   NOTE: Instances of this class should not be confused with those of ProviderIdentity
#
class Identity < OmniAuth::Identity::Models::ActiveRecord
	attr_accessible :name, :email, :password, :password_confirmation

	auth_key :name # Change to email if logging in with email is desired.

  validates :name,
    :presence => true,
    :length => { :in => 1..20 },
    :format => { :with => /^[a-zA-Z0-9_]+$/i,
                 :message => "Names must have an alphanumeric format." },
    :uniqueness => true

  validates :email,
  	:presence => true,
  	:format => { :with => /^[-a-z0-9_+\.]+\@([-a-z0-9]+\.)+[a-z0-9]{2,4}$/i,
  							 :message => "Invalid email format." },
  	:uniqueness => true

  # TODO: Strengthen password security constraints
  validates :password,
    :presence => true,
    :length => { :in => 6..300 }
end