class AccessToken < ActiveRecord::Base
  attr_accessible :token_expires_at, :token

  belongs_to :tokenable, :polymorphic => true

  before_create :generate_token

  scope :all_with_expired_token,
    where("access_tokens.token_expires_at < :now", {:now => Time.now})

  def token_expired?
  	self.token_expires_at < Time.now
  end

  def generate_token(expires = nil)
  	begin
  		self.token = SecureRandom.urlsafe_base64(32)
  	end while self.class.exists?(token: token)
  	self.token_expires_at = (expires || 25.minutes).from_now
  end

  def regenerate_token!(expires = nil)
  	self.generate_token(expires)
  	save!
  end
end