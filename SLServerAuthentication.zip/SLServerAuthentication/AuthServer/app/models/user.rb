class User < ActiveRecord::Base
  has_many :provider_identities
  has_one :access_token, :as => :tokenable, :dependent => :destroy

  before_create :create_access_token

  def self.find_by_access_token(token)
    (joins(:access_token).where("access_tokens.token = ?", token)).readonly(false).first
  end
end
