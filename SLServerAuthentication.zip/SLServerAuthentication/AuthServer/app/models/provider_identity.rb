class ProviderIdentity < ActiveRecord::Base

	attr_accessible :uid, :provider, :user_id

	belongs_to :user

	def self.from_omniauth(auth)
    find_by_provider_and_uid(auth["provider"], auth["uid"]) || create_with_omniauth(auth)
  end

  def self.create_with_omniauth(auth)
    create! do |provider_identity|
      provider_identity.provider = auth["provider"]
      provider_identity.uid = auth["uid"]
    end
  end
end
