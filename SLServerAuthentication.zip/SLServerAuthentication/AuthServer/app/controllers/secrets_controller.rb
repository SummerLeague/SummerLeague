class SecretsController < ApplicationController
  before_filter :require_auth

  def show
    render :status => 200, :json => {:secret_message => "Hello user #{@user.id}, the password is 'fidelio'."}
  end
end