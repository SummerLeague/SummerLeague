class UsersController < ApplicationController
  before_filter :require_auth
=begin
  def update
    if password_params.present?
      unless User.authenticate(@user.username, params[:user][:current_password]);
        render :status => 422, :json => {:error => "Incorrect password."}
        return false
      end
      @user.updating_password = true
    end

    if  @user.update_attributes(clean_params(standard_update_params))
      render :status => 200, :json => {
             :username => @user.username,
             :access_token => @user.access_token.token,
             :access_token_expires_at => @user.access_token.token_expires_at,
             :id => @user.id
           }
    else
      render :status => :unprocessable_entity, :json => { :error => @user.errors.full_messages.first }
    end
  end

  def destroy
    # Reauthenticate user with current password.
    unless User.authenticate(@user.username, params[:user][:password]);
      render :status => 422, :json => {:error => "Incorrect password."}
      return false
    end

    logout
    # TODO: Implement soft deletion. I believe the gem 'trashable' can do this for us.
    @user.destroy

    render :status => 200, :json => { notice: "Your account has been deleted." }
  end

  private

    def standard_update_params
      # Whitelisted params
      password_params.merge(params[:user].slice :username)
    end

    def password_params
      # Whitelisted params
      params[:user].slice :password, :password_confirmation
    end
=end
end