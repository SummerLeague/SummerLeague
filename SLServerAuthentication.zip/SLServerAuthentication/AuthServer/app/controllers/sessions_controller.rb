class SessionsController < ApplicationController
  def new
  end

  def create
    # If we have gotten here, OmniAuth has authenticated the user.

    # Find existing ProviderIdentity object or create a new one.
    provider_identity = ProviderIdentity.from_omniauth(env["omniauth.auth"])

    unless user = provider_identity.user
      # Essentially, we are either creating a new user for a fresh login, or adding a
      # provider_identity to an existing user that has authenticated with an access token.
      user = find_or_create_user_from_token
      provider_identity.update_attributes(:user_id => user.id)
    end

    user.access_token.regenerate_token! if user.access_token.token_expired?
    render :status => 200, :json => {
           :access_token => user.access_token.token,
           :access_token_expires_at => user.access_token.token_expires_at,
           :id => user.id
         }
  end

  def destroy
    # TODO: Not much we can do here since we dont login a user in a session.
    #   Should we clear his or her access token?
  end

  def failure
    identity = env['omniauth.identity']
    if identity
      # Failed registration.
      render :status => 422, :json => {:error => identity.errors.first }
    else
      # Failed login.
      render :status => 422, :json => {:error => "Invalid credentials."}
    end
  end

  protected
    def find_or_create_user_from_token
      # Check if user has authenticated with an access token and return that user or create a new one.
      user = User.find_by_access_token(request.headers["access_token"]) || User.create
      return user
    end
end