class ApplicationController < ActionController::Base
  protect_from_forgery

  unless Rails.application.config.consider_all_requests_local
    rescue_from Exception do |exception|
      render :status => 500
    end
    rescue_from ActionController::RoutingError, ActionController::UnknownController, ::AbstractController::ActionNotFound do |exception|
      render :status => 404
    end
  end

  private

	  def clean_params(dirty_params)
	    # Clean params including nested params.
	    clean_params ||= {}
	    dirty_params.each do |k, v|
	      clean_params[k] = v.is_a?(Hash) ? clean_params(v) : clean_value(v)
	    end
	    return clean_params
	  end

	  def clean_value(val)
	    HTMLEntities.new.decode(
	      Sanitize.clean(val, Sanitize::Config::RESTRICTED))
	  end

	  def require_auth
	    access_token = request.headers["access_token"]
	    @user = User.find_by_access_token(access_token)
	    if @user
	      if @user.access_token.token_expired?
	        render :status => 401, :json => { :error => "Access token expired." }
	      end
	    else
	      render :status => 401, :json => { :error => "Requires authorization." }
	    end
	  end

	  def not_found
	    raise ActionController::RoutingError.new('Not Found')
	  end
end
