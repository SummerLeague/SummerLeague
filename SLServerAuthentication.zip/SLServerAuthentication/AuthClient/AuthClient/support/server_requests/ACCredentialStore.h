//
//  ACCredentialStore.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/5/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ACCredentialStore : NSObject

- (BOOL)isLoggedIn;
- (void)clearSavedCredentials;
- (NSString *)accessToken;
- (NSString *)username;
- (NSString *)password;
- (NSString *)userId;
- (void)setAccessToken:(NSString *)accessToken;
- (void)setUsername:(NSString *)username;
- (void)setPassword:(NSString *)password;
- (void)setUserId:(NSString *)userId;

@end
