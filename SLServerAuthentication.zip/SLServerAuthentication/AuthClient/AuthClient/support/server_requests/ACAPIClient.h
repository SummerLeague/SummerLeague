//
//  ACAPIClient.h
//  AuthClient
//
//  Created by Bradley Griffith on 11/20/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFHTTPSessionManager.h"

@interface ACAPIClient : AFHTTPSessionManager

+ (ACAPIClient *)sharedClient;

@end
