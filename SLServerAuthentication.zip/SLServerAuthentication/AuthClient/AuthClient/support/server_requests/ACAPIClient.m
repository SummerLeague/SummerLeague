//
//  ACAPIClient.m
//  AuthClient
//
//  Created by Bradley Griffith on 11/20/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACAPIClient.h"
#import "ACCredentialStore.h"
#import "JSONResponseSerializerWithData.h"

@implementation ACAPIClient

+ (ACAPIClient *)sharedClient {
    static ACAPIClient *_sharedClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSURL *baseURL = [NSURL URLWithString:ServerApiUrl];
        _sharedClient = [[ACAPIClient alloc] initWithBaseURL:baseURL];
    });
    
    return _sharedClient;
}

- (id)initWithBaseURL:(NSURL *)url {
    self = [super initWithBaseURL:url];
    if (self) {
        self.responseSerializer = [JSONResponseSerializerWithData serializer];
        [self setAccessTokenHeader];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(tokenChanged:)
                                                     name:@"token-changed"
                                                   object:nil];
    }
    return self;
}

- (void)setAccessTokenHeader {
    ACCredentialStore *store = [[ACCredentialStore alloc] init];
    NSString *accessToken = [store accessToken];
    [self.requestSerializer setValue:accessToken forHTTPHeaderField:@"access_token"];
}


- (void)tokenChanged:(NSNotification *)notification {
    [self setAccessTokenHeader];
}

@end
