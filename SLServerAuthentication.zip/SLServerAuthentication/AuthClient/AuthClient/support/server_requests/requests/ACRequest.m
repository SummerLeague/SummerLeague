//
//  ACRequest.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/8/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACRequest.h"

@implementation ACRequest

- (NSDictionary *)jsonErrorMessagesForRequesError:(NSError *)error {
    NSString *jsonString = [error.userInfo objectForKey:@"responseBody"];
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *e;
    NSDictionary *errorMessages = [NSJSONSerialization JSONObjectWithData:jsonData options:nil error:&e];
    
    return errorMessages;
}

@end
