//
//  ACSecretRetriever.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/6/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACRequest.h"

typedef void (^SuccessWithSecretBlock)(NSString *secretMessage);
typedef void (^FailureWithMessageBlock)(NSString *errorMessage);

@interface ACSecretRetriever : ACRequest

- (NSURLSessionDataTask *)retrieveSecretWithSuccess:(SuccessWithSecretBlock)success failure:(FailureWithMessageBlock)failure;

@end
