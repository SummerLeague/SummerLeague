//
//  ACSecretRetriever.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/6/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACSecretRetriever.h"
#import "ACAPIClient.h"
#import "ACUserAuthenticator.h"

@implementation ACSecretRetriever

- (NSURLSessionDataTask *)retrieveSecretWithSuccess:(SuccessWithSecretBlock)success failure:(FailureWithMessageBlock)failure {
    
    void (^processCompletionBlock)(NSURLResponse *response, id responseObject, NSError *error ) = ^(NSURLResponse *response, id responseObject, NSError *error ) {
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        if (httpResponse.statusCode == 200 || httpResponse.statusCode == 304) {
            success([responseObject objectForKey:@"secret_message"]);
        }
        else {
            failure(@"Something went wrong.");
            NSLog(@"Recieved %@", response);
            NSLog(@"Received HTTP %d", httpResponse.statusCode);
        }
    };
    
    void (^authenticationFailureBlock)(NSURLSessionDataTask *task, NSString *errorMessage) = ^(NSURLSessionDataTask *task, NSString *errorMessage) {
        // TODO: Make this more helpful. A failure here means that the user could'nt be logged in with stored credentials.
        failure(errorMessage);
    };
    
    NSURLSessionDataTask *task = [[ACAPIClient sharedClient] GET:@"/secrets.json"
                                                      parameters:nil
                                                         success:^(NSURLSessionDataTask *task, id responseObject) {
                                                             NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
                                                             if (response.statusCode == 200 || response.statusCode == 304) {
                                                                 success([responseObject objectForKey:@"secret_message"]);
                                                             }
                                                             else {
                                                                 ACUserAuthenticator *authenticator = [[ACUserAuthenticator alloc] init];
                                                                 [authenticator refreshTokenAndRetryTask:task
                                                                                              completion:processCompletionBlock
                                                                                   authenticationFailure:authenticationFailureBlock];
                                                             }
                                                         }
                                                         failure:^(NSURLSessionDataTask *task, NSError *error) {
                                                             ACUserAuthenticator *authenticator = [[ACUserAuthenticator alloc] init];
                                                             [authenticator refreshTokenAndRetryTask:task
                                                                                          completion:processCompletionBlock
                                                                               authenticationFailure:authenticationFailureBlock];
                                                         }];
    
    return task;
}

@end
