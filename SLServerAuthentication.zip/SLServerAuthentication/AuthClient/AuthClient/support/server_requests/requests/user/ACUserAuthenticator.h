//
//  ACUserAuthenticator.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/5/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACRequest.h"

typedef void (^GenericSuccessBlock)();
typedef void (^GenericFailureBlock)(NSString *errorMessage);

@interface ACUserAuthenticator : ACRequest

- (NSURLSessionDataTask *)loginWithUsername:(NSString *)username
                                   password:(NSString *)password
                                    success:(GenericSuccessBlock)success
                                    failure:(GenericFailureBlock)failure;
- (void)loginWithStoredCredentials:(GenericSuccessBlock)success
                           failure:(GenericFailureBlock)failure;
- (void)refreshTokenAndRetryTask:(NSURLSessionDataTask *)task
                      completion:(void (^)(NSURLResponse *response, id responseObject, NSError *error ) )completion
           authenticationFailure:(void (^)(NSURLSessionDataTask *task, NSString *errorMessage ) )authenticationFailure;
@end
