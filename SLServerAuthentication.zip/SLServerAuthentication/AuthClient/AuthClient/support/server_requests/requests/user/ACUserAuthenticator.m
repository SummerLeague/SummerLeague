//
//  ACUserAuthenticator.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/5/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACUserAuthenticator.h"
#import "ACAPIClient.h"
#import "ACCredentialStore.h"

@interface ACUserAuthenticator ()
@property (nonatomic, strong)ACCredentialStore *credentialStore;
@end

@implementation ACUserAuthenticator

- (id)init {
    self = [super init];
    if (self) {
        _credentialStore = [[ACCredentialStore alloc] init];
    }
    return self;
}

- (NSURLSessionDataTask *)loginWithUsername:(NSString *)username
                 password:(NSString *)password
                  success:(GenericSuccessBlock)success
                  failure:(GenericFailureBlock)failure {
    
    id params = @{
                  @"auth_key": username ?: @"",
                  @"password": password ?: @""
                  };
    NSURLSessionDataTask *task = [[ACAPIClient sharedClient] POST:@"/auth/identity/callback"
                                                       parameters:params
                                                          success:^(NSURLSessionDataTask *task, id responseObject) {
                                                              NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
                                                              if (response.statusCode == 200) {
                                                                  [_credentialStore setAccessToken:responseObject[@"access_token"]];
                                                                  [_credentialStore setUsername:username];
                                                                  [_credentialStore setPassword:password];
                                                                  [_credentialStore setUserId:[responseObject[@"id"] stringValue]];
                                                                  success();
                                                              }
                                                              else {
                                                                  failure(@"Something went wrong.");
                                                                  NSLog(@"Recieved %@", response);
                                                                  NSLog(@"Recieved HTTP %d", response.statusCode);
                                                              }
                                 
                                                          }
                                                          failure:^(NSURLSessionDataTask *task, NSError *error) {
                                                              
                                                              NSDictionary *errorMessages = [self jsonErrorMessagesForRequesError:error];
                                                              NSLog(@"%@", errorMessages);
                                                              
                                                              // TODO / SOON: Use the error messages.
                                                              failure([error localizedDescription]);
                                                          }];
    return task;
}

- (void)loginWithStoredCredentials:(GenericSuccessBlock)success
                           failure:(GenericFailureBlock)failure {
    NSString *username = [_credentialStore username];
    NSString *password = [_credentialStore password];
    
    [self loginWithUsername:username password:password success:success failure:failure];
}

- (void)refreshTokenAndRetryTask:(NSURLSessionDataTask *)task
                      completion:(void (^)(NSURLResponse *response, id responseObject, NSError *error ) )completion
           authenticationFailure:(void (^)(NSURLSessionDataTask *task, NSString *errorMessage ) )authenticationFailure {
    
    NSString *username = [_credentialStore username];
    NSString *password = [_credentialStore password];

    [self loginWithUsername:username password:password success:^{
        // Retry request.
        NSLog(@"Retrying Request");
        NSURLRequest *retryRequest = [self requestForOriginalTask:task];
        NSURLSessionDataTask *retryTask = [[ACAPIClient sharedClient] dataTaskWithRequest:retryRequest
                                                                        completionHandler:completion];
        // Resume task.
        [retryTask resume];
    } failure:^(NSString *errorMessage) {
        authenticationFailure(task, errorMessage);
    }];
}

- (NSMutableURLRequest *)requestForOriginalTask:(NSURLSessionDataTask *)task {
    NSMutableURLRequest *request = [task.originalRequest mutableCopy];
    [request addValue:nil forHTTPHeaderField:@"access_token"];
    [request addValue:[_credentialStore accessToken] forHTTPHeaderField:@"access_token"];
    
    return request;
}

@end
