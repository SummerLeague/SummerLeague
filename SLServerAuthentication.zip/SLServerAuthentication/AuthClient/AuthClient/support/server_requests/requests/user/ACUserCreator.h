//
//  ACUserCreator.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/8/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACRequest.h"

typedef void (^GenericSuccessBlock)();
typedef void (^GenericFailureBlock)(NSString *errorMessage);

@interface ACUserCreator : ACRequest

- (NSURLSessionDataTask *)createUserWithUsername:(NSString *)username
                                           email:(NSString *)email
                                        password:(NSString *)password
                            passwordConfirmation:(NSString *)passwordConfirmation
                                         success:(GenericSuccessBlock)success
                                         failure:(GenericFailureBlock)failure;
@end
