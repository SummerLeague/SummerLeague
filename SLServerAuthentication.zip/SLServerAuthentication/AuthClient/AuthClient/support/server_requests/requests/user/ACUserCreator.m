//
//  ACUserCreator.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/8/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACUserCreator.h"
#import "ACAPIClient.h"
#import "ACCredentialStore.h"

@interface ACUserCreator ()
@property (nonatomic, strong)ACCredentialStore *credentialStore;
@end

@implementation ACUserCreator

- (id)init {
    self = [super init];
    if (self) {
        _credentialStore = [[ACCredentialStore alloc] init];
    }
    return self;
}

- (NSURLSessionDataTask *)createUserWithUsername:(NSString *)username
                                           email:(NSString *)email
                                        password:(NSString *)password
                            passwordConfirmation:(NSString *)passwordConfirmation
                                         success:(GenericSuccessBlock)success
                                         failure:(GenericFailureBlock)failure {
    
    id params = @{
                  @"name": username ?: @"",
                  @"email": email ?: @"",
                  @"password": password ?: @"",
                  @"password_confirmation": passwordConfirmation ?: @""
                  };
    
    NSURLSessionDataTask *task = [[ACAPIClient sharedClient] POST:@"/auth/identity/register"
                                                       parameters:params
                                                          success:^(NSURLSessionDataTask *task, id responseObject) {
                                                              NSHTTPURLResponse *response = (NSHTTPURLResponse *)task.response;
                                                              if (response.statusCode == 200) {
                                                                  [_credentialStore setAccessToken:responseObject[@"access_token"]];
                                                                  [_credentialStore setUsername:username];
                                                                  [_credentialStore setPassword:password];
                                                                  [_credentialStore setUserId:[responseObject[@"id"] stringValue]];
                                                                  success();
                                                              }
                                                              else {
                                                                  failure(@"Something went wrong.");
                                                                  NSLog(@"Recieved %@", response);
                                                                  NSLog(@"Recieved HTTP %d", response.statusCode);
                                                              }
                                                          }
                                                          failure:^(NSURLSessionDataTask *task, NSError *error) {
                                                              
                                                              NSDictionary *errorMessages = [self jsonErrorMessagesForRequesError:error];
                                                              NSLog(@"%@", errorMessages);
                                                              
                                                              // TODO / SOON: Use the error messages.
                                                              failure(error.localizedDescription);
                                                          }];
    
    return task;
}

@end
