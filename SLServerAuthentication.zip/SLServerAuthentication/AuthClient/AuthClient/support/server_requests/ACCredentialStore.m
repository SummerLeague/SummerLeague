//
//  ACCredentialStore.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/5/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACCredentialStore.h"
#import "SSKeychain.h"

#define SERVICE_NAME @"Example-Auth"
#define ACCESS_TOKEN_KEY @"access_token"
#define USERNAME_KEY @"username"
#define ID_KEY @"userId"
#define PASSWORD_KEY @"password"

@implementation ACCredentialStore

- (BOOL)isLoggedIn {
    return [self accessToken] != nil;
}

- (void)clearSavedCredentials {
    [self setAccessToken:nil];
    [self setUsername:nil];
    [self setPassword:nil];
    [self setUserId:nil];
}

- (NSString *)accessToken {
    return [self secureValueForKey:ACCESS_TOKEN_KEY];
}

- (NSString *)username {
    return [self secureValueForKey:USERNAME_KEY];
}

- (NSString *)password {
    return [self secureValueForKey:PASSWORD_KEY];
}

- (NSString *)userId {
    return [self secureValueForKey:ID_KEY];
}

- (void)setAccessToken:(NSString *)accessToken {
    [self setSecureValue:accessToken forKey:ACCESS_TOKEN_KEY];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"token-changed" object:self];
}

- (void)setUsername:(NSString *)username {
    [self setSecureValue:username forKey:USERNAME_KEY];
}

- (void)setPassword:(NSString *)password {
    [self setSecureValue:password forKey:PASSWORD_KEY];
}

- (void)setUserId:(NSString *)userId {
    [self setSecureValue:userId forKey:ID_KEY];
}

- (void)setSecureValue:(NSString *)value forKey:(NSString *)key {
    // In the keychain, there are passwords for various services.
    // We utilize these key/values to store sensitive key/value pairs.
    if (value) {
        [SSKeychain setPassword:value
                     forService:SERVICE_NAME
                        account:key];
    }
    else {
        [SSKeychain deletePasswordForService:SERVICE_NAME account:key];
    }
}

- (NSString *)secureValueForKey:(NSString *)key {
    return [SSKeychain passwordForService:SERVICE_NAME account:key];
}

@end
