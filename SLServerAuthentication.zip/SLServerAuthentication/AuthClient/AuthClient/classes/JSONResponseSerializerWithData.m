//
//  JSONResponseSerializerWithData.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/8/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "JSONResponseSerializerWithData.h"

@implementation JSONResponseSerializerWithData

- (id)responseObjectForResponse:(NSURLResponse *)response
                           data:(NSData *)data
                          error:(NSError *__autoreleasing *)error {
    id JSONObject = [super responseObjectForResponse:response data:data error:error]; // may mutate `error`
    
    if (*error) {
        NSMutableDictionary *mutableUserInfo = [(*error).userInfo mutableCopy];
        NSString *responseBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        [mutableUserInfo setObject:responseBody forKey:@"responseBody"];
        NSError *newError = [NSError errorWithDomain:(*error).domain code:(*error).code userInfo:[mutableUserInfo copy]];
        (*error) = newError;
    }
    
    return JSONObject;
}

@end