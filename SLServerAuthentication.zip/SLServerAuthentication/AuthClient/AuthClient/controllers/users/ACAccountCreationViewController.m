//
//  ACAccountCreationViewController.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/8/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACAccountCreationViewController.h"
#import "ACUserCreator.h"
#import "SVProgressHUD.h"

@interface ACAccountCreationViewController ()
@end

@implementation ACAccountCreationViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // Show keyboad.
	[_usernameField becomeFirstResponder];
}

// TODO: Determine which one of these is appropriate, if either, for executing code
// prior to all events that segue away from this controller.
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    [self.view endEditing:YES];
}

- (IBAction)creatAccount:(id)sender {
    [SVProgressHUD show];
    ACUserCreator *userCreator = [[ACUserCreator alloc] init];
    [userCreator createUserWithUsername:_usernameField.text
                                  email:_emailField.text
                               password:_passwordField.text
                   passwordConfirmation:_passwordConfirmationField.text
                                success:^{
                                    // Dismiss HUD.
                                    [SVProgressHUD dismiss];
                                    [self performSegueWithIdentifier:@"segueToDashboard" sender:self];
                                }
                                failure:^(NSString *errorMessage) {
                                    [_usernameField becomeFirstResponder];
                                    [SVProgressHUD showErrorWithStatus:errorMessage];
                                }];
}

@end
