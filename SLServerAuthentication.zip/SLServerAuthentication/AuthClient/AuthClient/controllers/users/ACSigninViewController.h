//
//  ACSigninViewController.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/5/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACSigninViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;

- (IBAction)signin:(id)sender;

@end
