//
//  ACSecretsViewController.m
//  AuthClient
//
//  Created by Bradley Griffith on 12/7/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import "ACSecretsViewController.h"
#import "ACSecretRetriever.h"
#import "ACCredentialStore.h"
#import "SVProgressHUD.h"

@implementation ACSecretsViewController

- (IBAction)signOut:(id)sender {
    ACCredentialStore *credentialStore = [[ACCredentialStore alloc] init];
    [credentialStore clearSavedCredentials];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:nil];
    UIViewController *signinViewController = [storyboard
                                              instantiateViewControllerWithIdentifier:@"ACAccountOptionsNavigationController"];
    
    [self presentViewController:signinViewController animated:YES completion:nil];
}

- (IBAction)retrieveSecret:(id)sender {
    [SVProgressHUD show];
    
    ACSecretRetriever *secretRetriever = [[ACSecretRetriever alloc] init];
    [secretRetriever retrieveSecretWithSuccess:^(NSString *secretMessage){
        [SVProgressHUD dismiss];
        _secretsTextView.text = secretMessage;
        
    } failure:^(NSString *errorMessage) {
        [SVProgressHUD showErrorWithStatus:errorMessage];
    }];
}

- (IBAction)clearAccessToken:(id)sender {
    ACCredentialStore *credentialStore = [[ACCredentialStore alloc] init];
    [credentialStore setAccessToken:nil];
}

@end
