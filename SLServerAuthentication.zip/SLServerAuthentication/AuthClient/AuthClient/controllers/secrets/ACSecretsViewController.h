//
//  ACSecretsViewController.h
//  AuthClient
//
//  Created by Bradley Griffith on 12/7/13.
//  Copyright (c) 2013 Bradley Griffith. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACSecretsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *secretsTextView;

- (IBAction)signOut:(id)sender;
- (IBAction)retrieveSecret:(id)sender;
- (IBAction)clearAccessToken:(id)sender;

@end
