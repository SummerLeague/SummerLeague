module.exports = function(app) {
	// Home
	app.get('/', function(req, res) {
		res.send('Hello world !');
	});
	// Load all other routes
	[
	  "barcodes",
	  "sessions",
	  "posts",
	  "users"
	].forEach(function (routeName) {
	    require("app/routes/" + routeName)(app);
	});

	// OK, routes are loaded, now use the router:
	app.use(app.router);

	// Finally, use any error handlers
	app.use(require("app/middleware/").notFound);
};