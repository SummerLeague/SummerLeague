RulingClass
===========

![obey](http://i.imgur.com/7SGkAyW.jpg)


Dependencies
-----

In order for image uploading to work with [imager](https://github.com/madhums/node-imager), you will need to have [ImageMagick](http://www.imagemagick.org/script/binary-releases.php#macosx) installed.


