var Barcode = require('app/models/barcode');

function index(req, res) {
	return Barcode.find(function(err, barcodes) {
		if(err) {
			return res.send(422, {
				error: err
			});
		}
		return res.send(200, barcodes);
	});
};

function search(req, res) {
	// TODO: Should we assume that barcodes hitting here are legit? Seems I could pass anything up. Maybe we need a whitelist or validations.
	// TODO/DISCUSS: Consider making these body params so the routing isnt so prone to conflicts with actual resources.
	var code_type = req.params.code_type,
			code = req.params.code;
	Barcode.findOrCreateByTypeAndCode(code_type, code, function(err, barcode) {
		if (err) {
			// TODO: Handle this error more appropriately.
			return res.send(422, {
				error: err
			});
		}
		barcode.incrementHits(function(err, barcode) {
			if (err) {
				// TODO: Log.
				return res.send(500);
			}
			return res.send(200, barcode);
		});
	});
};


function setup(app) {
	app.get('/barcodes', index);
	app.get('/barcodes/:code_type/:code', search);
}

module.exports = setup;