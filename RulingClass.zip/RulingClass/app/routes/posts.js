var Post = require('app/models/post'),
		User = require('app/models/user'),
		Barcode = require('app/models/barcode'),
    requireAuth = require("app/middleware/").requireAuth; // TODO: Investigate how others include middleware like this.;


function index(req, res) {
  // TODO/DISCUSS: Not incredibly happy with this API design. Feel like the route should be more explicit...
  //   i.e.; scoped to a user or a barcode rather than taking ids for either as URL params...
  var user_id = req.param('user_id'),
      barcode_id = req.param('barcode_id');

  var callback = function(err, response) {
    if (!response) {
      // TODO: Make this better.
      //   Response should at least contain an empty object here. Hence the 500.
      return res.send(500);
    }
    return res.send(200, response);
  }

  if (user_id) {
    User.findById(user_id, function (err, user) {
      if (!user) {
        return res.send(422, { error: "No user found for that user id." });
      }
      user.posts({ page: req.param('page'), perPage: req.param('per_page') }, callback);
    });
  }
  else if (barcode_id) {
    Barcode.findById(barcode_id, function (err, barcode) {
      if (!barcode) {
        return res.send(422, { error: "No barcode found for that barcode id." });
      }
      barcode.posts({ page: req.param('page'), perPage: req.param('per_page') }, callback);
    });
  }
  else {
    res.send(422, {
      error: "Must provide a valid id for a barcode or a user."
    });
  }
}

function show(req, res) {
  Post.load(req.params.post_id, function(err, post){
    if (!post) {
      return res.send(404);
    }
    return res.send(200, {
      post: post
    });
  });
}

function create(req, res) {
  var files = req.files || {};
	var post = new Post(req.body);
	post.creator = req.current_user;

  post.uploadAndSave(files.image, function (err, post) {
    if (!post) {
      return res.send(422, {
        error: err
      });
    }
    return res.send(200, {
      post: post
    });
  })
};


function setup(app) {
  app.get('/posts', index);
  app.get('/posts/:post_id', show);
  app.post('/posts', requireAuth, create);
}

module.exports = setup;