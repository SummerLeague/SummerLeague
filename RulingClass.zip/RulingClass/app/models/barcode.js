var mongoose = require('mongoose'),
		Schema = mongoose.Schema,
		extend = require('node.extend'),
		Post = require('app/models/post');

var BarcodeSchema = new Schema({
	code: { type: String, required: true },
	code_type: { type: String, required: true },
	hits: { type: Number, default: 0 }
});


/*
	Class methods.
*/
BarcodeSchema.statics = extend({

	findOrCreateByTypeAndCode: function(code_type, code, callback) {
		var self = this;
		this.findOne({ code_type: code_type, code: code }, function(err, barcode) {
			if (!barcode) {
				var new_barcode = new self({
					code: code,
					code_type: code_type
				});

				new_barcode.save(function (err, barcode) {
					callback(err, barcode);
				});
			}
			else {
				callback(null, barcode);
			}
		});
	}

}, BarcodeSchema.statics);


/*
	Instance methods.
*/
BarcodeSchema.methods = extend({

	incrementHits: function(callback) {
		// NOTE: If your're thinking: 'It'd be nice to just call this.hits.$inc() and save the instance'... mongoose 3 removed this option.
		//   http://mongoosejs.com/docs/migration.html#mongoosenumber
		this.model('Barcode').findOneAndUpdate({ _id: this.id }, { $inc: { hits: 1 } }, null, function(err, barcode) {
			callback(err, barcode);
		});
	},

	posts: function(options, callback) {
		var options = options || {};
		options.page = (options.page > 0 ? options.page : 1) - 1;
		options.perPage = options.perPage || 10;
		options.criteria = { barcode: this._id };

		Post.list(options, function(err, posts) {
		  if (err) {
		  	callback(err, null);
		  }
		  else {
			  Post.count(options.criteria, function (err, count) {
			  	if (err) {
			  		callback(err, null);
			  	}
			  	else {
			  		callback(null, {
			  			page: options.page + 1,
			  			pages: Math.ceil(count / options.perPage),
			  			posts: posts
			  		})
			  	}
			  });
			}
		});
	}

}, BarcodeSchema.methods);


module.exports = mongoose.model('Barcode', BarcodeSchema);