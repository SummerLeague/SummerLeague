var mongoose = require('mongoose'),
    Imager = require('imager'),
		Schema = mongoose.Schema,
		extend = require('node.extend'),
    imagerConfig = require('config').imager;

var PostSchema = new Schema({
	text: { type: String, default : '', trim : true },
	creator: { type: Schema.ObjectId, ref: 'User', required: true },
	barcode: { type: Schema.ObjectId, ref: 'Barcode', required: true },
  image: {
    cdnUri: { type: String },
    files: []
  },
	createdAt: { type : Date, default : Date.now }
});


/*
  Validations.
*/
// TODO: We need to validate _something_ on these posts to make them have
// meaning (i.e.; they should have content of some kind).


/*
  Hooks.
*/
PostSchema.pre('remove', function (next) {
  var imager = new Imager(imagerConfig, 'S3'),
      files = this.image.files;

  // if there are files associated with the item, remove from S3 too
  imager.remove(files, function (err) {
    if (err) {
      return next(err);
    }
  }, 'post');

  next();
});


/*
	Class methods.
*/
PostSchema.statics = extend({

  load: function (id, callback) {
    this.findOne({ _id : id })
      .populate('creator', 'nickname _id')
      .populate('barcode', 'code code_type _id')
      .exec(callback);
  },

	list: function (options, callback) {
    var options = options || {},
        criteria = options.criteria || {};

    this.find(criteria)
      .populate('creator', 'nickname _id')
      .populate('barcode', 'code code_type _id')
      .sort({'createdAt': -1}) // sort by date
      .limit(options.perPage)
      .skip(options.perPage * options.page)
      .exec(callback);
  }

}, PostSchema.statics);


/*
  Instance methods.
*/
PostSchema.methods = extend({

  // Save an article and upload image if present.
  uploadAndSave: function (images, callback) {
    if (!images) {
      this.save(function(err, post) {
        if (err) {
          return callback(err, null);
        }
        else {
          post
          .populate('creator', 'nickname _id')
          .populate('barcode', 'code code_type _id')
          .populate(callback);
        }
      });
    }
    else {
      var self = this,
          imager = new Imager(imagerConfig, 'S3');
      this.validate(function (err) {
        if (err) {
          return callback(err, null);
        }
        imager.upload([images], function (err, cdnUri, files) {
          if (err) {
            return callback(err, null);
          }
          if (files.length) {
            self.image = { cdnUri : cdnUri, files : files }
          }
          self.save(function(err, post) {
            if (err) {
              return callback(err, null);
            }
            post
            .populate('creator', 'nickname _id')
            .populate('barcode', 'code code_type _id')
            .populate(callback);
          });
        }, 'post');
      });
    }
  }

}, PostSchema.methods);

module.exports = mongoose.model('Post', PostSchema);
